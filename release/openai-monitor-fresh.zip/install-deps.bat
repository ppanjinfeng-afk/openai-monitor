@echo off
chcp 65001 >nul
cd /d %~dp0
echo 正在安装依赖，请稍等...
npm install
echo.
echo 安装完成。按任意键关闭窗口。
pause >nul

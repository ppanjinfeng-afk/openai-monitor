const db = require('../db');
const fetch = require('node-fetch');
const crypto = require('crypto');
const http = require('http');
const telegram = require('./telegram');

// OpenAI OAuth constants (same as Codex CLI)
const OAUTH_CLIENT_ID = 'app_EMoamEEZ73f0CkXaXp7hrann';
const OAUTH_AUTHORIZE_URL = 'https://auth.openai.com/oauth/authorize';
const OAUTH_TOKEN_URL = 'https://auth.openai.com/oauth/token';
const OAUTH_REDIRECT_URI = 'http://localhost:1455/auth/callback';
const OAUTH_AUDIENCE = 'https://api.openai.com/v1';
const OAUTH_SCOPES = 'openid profile email offline_access';

const STATUS = {
  ACTIVE: 'active',
  BANNED: 'banned',
  INVALID_CREDENTIALS: 'invalid_credentials',
  RATE_LIMITED: 'rate_limited',
  ERROR: 'error',
  UNKNOWN: 'unknown',
  NO_PASSWORD: 'no_password',
};

const PRESERVED_TRANSIENT_STATUSES = new Set([
  STATUS.ACTIVE,
  STATUS.BANNED,
  STATUS.INVALID_CREDENTIALS,
  STATUS.RATE_LIMITED,
]);

function sleep(ms) {
  return new Promise(resolve => setTimeout(resolve, ms));
}

function normalizeCheckResult(account, result) {
  if (!result?.transient) {
    return result;
  }

  if (!PRESERVED_TRANSIENT_STATUSES.has(account.status)) {
    return result;
  }

  return {
    ...result,
    status: account.status,
    message: `上游检查接口临时异常，已保留原状态：${result.message}`,
  };
}

async function checkWithTokenWithRetry(accessToken) {
  const maxAttempts = 3;
  let lastTransientFailure = null;

  for (let attempt = 1; attempt <= maxAttempts; attempt++) {
    try {
      const res = await fetch('https://api.openai.com/v1/me', {
        headers: { 'Authorization': `Bearer ${accessToken}` },
      });

      if (res.status === 200) {
        return { status: STATUS.ACTIVE, message: '令牌有效，账号正常' };
      }

      if (res.status === 401) {
        return { status: null, message: 'token_expired' };
      }

      if (res.status === 403) {
        const body = await res.json().catch(() => ({}));
        const msg = body?.error?.message || '';
        if (msg.toLowerCase().includes('banned') || msg.toLowerCase().includes('deactivated')) {
          return { status: STATUS.BANNED, message: '账号已被封禁' };
        }
        return { status: STATUS.BANNED, message: '访问被拒绝，可能已被封禁 (403)' };
      }

      if (res.status === 429) {
        return { status: STATUS.RATE_LIMITED, message: '请求限流，稍后重试' };
      }

      if (res.status === 404 || res.status >= 500) {
        lastTransientFailure = {
          status: STATUS.ERROR,
          transient: true,
          message: `OpenAI 检查接口临时返回 HTTP ${res.status}`,
        };

        if (attempt < maxAttempts) {
          await sleep(600 * attempt);
          continue;
        }

        return lastTransientFailure;
      }

      return { status: STATUS.ERROR, message: `HTTP ${res.status}` };
    } catch (err) {
      lastTransientFailure = {
        status: STATUS.ERROR,
        transient: true,
        message: `OpenAI 检查接口网络异常: ${err.message}`,
      };

      if (attempt < maxAttempts) {
        await sleep(600 * attempt);
        continue;
      }
    }
  }

  return lastTransientFailure || { status: STATUS.ERROR, message: '检查接口未知异常' };
}

// ===== PKCE helpers =====
function generateCodeVerifier() {
  return crypto.randomBytes(32).toString('base64url');
}

function generateCodeChallenge(verifier) {
  return crypto.createHash('sha256').update(verifier).digest('base64url');
}

function generateState() {
  return crypto.randomBytes(16).toString('hex');
}

// ===== OAuth Token-based check (for accounts that already have tokens) =====
async function checkWithToken(accessToken) {
  return checkWithTokenWithRetry(accessToken);
  try {
    const res = await fetch('https://api.openai.com/v1/me', {
      headers: { 'Authorization': `Bearer ${accessToken}` },
    });

    if (res.status === 200) {
      return { status: STATUS.ACTIVE, message: '令牌有效，账号正常' };
    } else if (res.status === 401) {
      return { status: null, message: 'token_expired' }; // Need refresh
    } else if (res.status === 403) {
      const body = await res.json().catch(() => ({}));
      const msg = body?.error?.message || '';
      if (msg.toLowerCase().includes('banned') || msg.toLowerCase().includes('deactivated')) {
        return { status: STATUS.BANNED, message: '账号已被封禁' };
      }
      return { status: STATUS.BANNED, message: '访问被拒绝，可能已被封禁 (403)' };
    } else if (res.status === 429) {
      return { status: STATUS.RATE_LIMITED, message: '请求限流，稍后重试' };
    }
    return { status: STATUS.ERROR, message: `HTTP ${res.status}` };
  } catch (err) {
    return { status: STATUS.ERROR, message: `网络错误: ${err.message}` };
  }
}

// ===== Refresh token =====
async function refreshAccessToken(refreshToken) {
  try {
    const res = await fetch(OAUTH_TOKEN_URL, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        grant_type: 'refresh_token',
        client_id: OAUTH_CLIENT_ID,
        refresh_token: refreshToken,
      }),
    });

    if (res.status === 200) {
      const data = await res.json();
      return {
        access_token: data.access_token,
        refresh_token: data.refresh_token || refreshToken,
        expires_in: data.expires_in,
      };
    } else {
      const body = await res.json().catch(() => ({}));
      return { error: body?.error_description || body?.error || `HTTP ${res.status}` };
    }
  } catch (err) {
    return { error: err.message };
  }
}

// ===== Main check account logic =====
async function checkAccount(account) {
  if (!account.password && !account.access_token) {
    return { status: STATUS.NO_PASSWORD, message: '未配置密码且无令牌' };
  }

  // Step 1: If we have an access token, try it first
  if (account.access_token) {
    const tokenResult = await checkWithToken(account.access_token);

    if (tokenResult.status !== null) {
      return tokenResult;
    }

    // Token expired, try refresh
    if (account.refresh_token) {
      console.log(`[Checker] Token expired for ${account.email}, refreshing...`);
      const refreshed = await refreshAccessToken(account.refresh_token);

      if (!refreshed.error) {
        // Save new tokens
        db.prepare(`UPDATE accounts SET access_token = ?, refresh_token = ?, updated_at = datetime('now') WHERE id = ?`)
          .run(refreshed.access_token, refreshed.refresh_token, account.id);

        // Check with new token
        const newResult = await checkWithToken(refreshed.access_token);
        if (newResult.status !== null) {
          return newResult;
        }
      } else {
        console.log(`[Checker] Refresh failed for ${account.email}: ${refreshed.error}`);
        // If refresh fails, the account might be banned
        if (refreshed.error.toLowerCase().includes('banned') || refreshed.error.toLowerCase().includes('deactivated')) {
          return { status: STATUS.BANNED, message: '刷新令牌失败，账号可能被封禁' };
        }
      }
    }
  }

  // Step 2: If no valid token and no password, mark as needing re-auth
  if (!account.password) {
    return { status: STATUS.INVALID_CREDENTIALS, message: '令牌已过期，请重新授权' };
  }

  // Step 3: Attempt headless OAuth via Resource Owner Password Grant
  // Note: OpenAI may not support this grant type directly.
  // In that case, we fall back to their auth API
  const loginResult = await attemptDirectLogin(account);
  return loginResult;
}

// ===== Direct login attempt via OpenAI auth API =====
async function attemptDirectLogin(account) {
  try {
    // Try the OpenAI auth API flow
    // Step 1: Get a login session
    const sessionRes = await fetch('https://auth.openai.com/api/auth/csrf', {
      method: 'GET',
      headers: {
        'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36',
      },
    });

    let csrfToken = '';
    if (sessionRes.status === 200) {
      const data = await sessionRes.json().catch(() => ({}));
      csrfToken = data.csrfToken || '';
    }

    // Step 2: Attempt sign-in
    const signInRes = await fetch('https://auth.openai.com/api/auth/callback/login-web', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/x-www-form-urlencoded',
        'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36',
        'Origin': 'https://auth.openai.com',
        'Referer': 'https://auth.openai.com/',
      },
      body: new URLSearchParams({
        username: account.email,
        password: account.password,
        csrfToken: csrfToken,
        callbackUrl: '/',
        json: 'true',
      }).toString(),
      redirect: 'manual',
    });

    const statusCode = signInRes.status;
    const responseText = await signInRes.text().catch(() => '');
    const responseLower = responseText.toLowerCase();

    // Parse response
    if (statusCode === 200 || statusCode === 302 || statusCode === 303) {
      // Try to extract tokens from the response
      try {
        const data = JSON.parse(responseText);
        if (data.url && !data.url.includes('error')) {
          return { status: STATUS.ACTIVE, message: '登录成功，账号正常' };
        }
        if (data.error) {
          if (responseLower.includes('banned') || responseLower.includes('deactivated') || responseLower.includes('suspended')) {
            return { status: STATUS.BANNED, message: '账号已被封禁' };
          }
          return { status: STATUS.INVALID_CREDENTIALS, message: data.error };
        }
      } catch {
        // Not JSON, check redirect
        const location = signInRes.headers.get('location') || '';
        if (location.includes('error')) {
          return { status: STATUS.INVALID_CREDENTIALS, message: '登录失败' };
        }
        return { status: STATUS.ACTIVE, message: '登录成功（重定向）' };
      }
      return { status: STATUS.ACTIVE, message: '登录响应正常' };
    }

    if (statusCode === 401 || statusCode === 400) {
      if (responseLower.includes('banned') || responseLower.includes('deactivated') || responseLower.includes('suspended') || responseLower.includes('disabled')) {
        return { status: STATUS.BANNED, message: '账号已被封禁' };
      }
      if (responseLower.includes('wrong') || responseLower.includes('invalid') || responseLower.includes('incorrect')) {
        return { status: STATUS.INVALID_CREDENTIALS, message: '邮箱或密码错误' };
      }
      return { status: STATUS.INVALID_CREDENTIALS, message: `登录失败 (${statusCode})` };
    }

    if (statusCode === 403) {
      if (responseLower.includes('banned') || responseLower.includes('suspended')) {
        return { status: STATUS.BANNED, message: '账号已被封禁 (403)' };
      }
      return { status: STATUS.BANNED, message: '访问被拒绝' };
    }

    if (statusCode === 429) {
      return { status: STATUS.RATE_LIMITED, message: '登录请求过于频繁' };
    }

    return { status: STATUS.ERROR, message: `HTTP ${statusCode}: 未知响应` };
  } catch (err) {
    return { status: STATUS.ERROR, message: `登录出错: ${err.message}` };
  }
}

// ===== OAuth Authorization (browser-based, for initial token acquisition) =====
// This starts a local server, opens the auth URL, and waits for callback
function buildAuthorizationUrl(codeChallenge, state, loginHint) {
  const params = new URLSearchParams({
    client_id: OAUTH_CLIENT_ID,
    redirect_uri: OAUTH_REDIRECT_URI,
    response_type: 'code',
    scope: OAUTH_SCOPES,
    audience: OAUTH_AUDIENCE,
    state: state,
    code_challenge: codeChallenge,
    code_challenge_method: 'S256',
    prompt: 'login',
  });
  if (loginHint) {
    params.append('login_hint', loginHint);
  }
  return `${OAUTH_AUTHORIZE_URL}?${params.toString()}`;
}

async function exchangeCodeForTokens(code, codeVerifier) {
  const res = await fetch(OAUTH_TOKEN_URL, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({
      grant_type: 'authorization_code',
      client_id: OAUTH_CLIENT_ID,
      code: code,
      redirect_uri: OAUTH_REDIRECT_URI,
      code_verifier: codeVerifier,
    }),
  });

  if (res.status === 200) {
    return await res.json();
  } else {
    const body = await res.json().catch(() => ({}));
    throw new Error(body?.error_description || body?.error || `HTTP ${res.status}`);
  }
}

// Start OAuth flow for a specific account (returns auth URL for user to open)
function startOAuthFlow(loginHint) {
  const codeVerifier = generateCodeVerifier();
  const codeChallenge = generateCodeChallenge(codeVerifier);
  const state = generateState();
  const authUrl = buildAuthorizationUrl(codeChallenge, state, loginHint);

  return { authUrl, codeVerifier, state };
}

// Wait for OAuth callback on local server
function waitForOAuthCallback(codeVerifier, state, timeout = 120000) {
  return new Promise((resolve, reject) => {
    const server = http.createServer(async (req, res) => {
      const url = new URL(req.url, `http://localhost:19275`);

      if (url.pathname === '/callback') {
        const code = url.searchParams.get('code');
        const returnedState = url.searchParams.get('state');
        const error = url.searchParams.get('error');

        if (error) {
          res.writeHead(200, { 'Content-Type': 'text/html; charset=utf-8' });
          res.end('<html><body><h2>❌ 授权失败</h2><p>' + error + '</p><p>可以关闭此页面</p></body></html>');
          server.close();
          reject(new Error(`OAuth error: ${error}`));
          return;
        }

        if (returnedState !== state) {
          res.writeHead(200, { 'Content-Type': 'text/html; charset=utf-8' });
          res.end('<html><body><h2>❌ 状态不匹配</h2><p>可以关闭此页面</p></body></html>');
          server.close();
          reject(new Error('State mismatch'));
          return;
        }

        try {
          const tokens = await exchangeCodeForTokens(code, codeVerifier);
          res.writeHead(200, { 'Content-Type': 'text/html; charset=utf-8' });
          res.end('<html><body style="background:#0a0e17;color:#f0f4f8;font-family:Inter,sans-serif;display:flex;align-items:center;justify-content:center;height:100vh"><div style="text-align:center"><h2>✅ 授权成功！</h2><p>令牌已保存，可以关闭此页面</p></div></body></html>');
          server.close();
          resolve(tokens);
        } catch (err) {
          res.writeHead(200, { 'Content-Type': 'text/html; charset=utf-8' });
          res.end('<html><body><h2>❌ 令牌交换失败</h2><p>' + err.message + '</p></body></html>');
          server.close();
          reject(err);
        }
      }
    });

    server.listen(19275, () => {
      console.log('[OAuth] Callback server listening on port 19275');
    });

    // Timeout
    setTimeout(() => {
      server.close();
      reject(new Error('OAuth timeout'));
    }, timeout);
  });
}

// ===== Account check orchestration =====
async function checkSingleAccount(accountId) {
  const account = db.prepare(`SELECT * FROM accounts WHERE id = ?`).get(accountId);
  if (!account) {
    throw new Error('Account not found');
  }

  const rawResult = await checkAccount(account);
  const result = normalizeCheckResult(account, rawResult);
  const oldStatus = account.status;
  const now = new Date().toISOString();

  db.prepare(`UPDATE accounts SET status = ?, last_checked = ?, updated_at = ? WHERE id = ?`)
    .run(result.status, now, now, account.id);

  db.prepare(`INSERT INTO check_logs (account_id, status, message) VALUES (?, ?, ?)`)
    .run(account.id, result.status, result.message);

  // Send alerts on status change
  if (oldStatus !== result.status && oldStatus !== 'unknown') {
    if (result.status === STATUS.BANNED) {
      await telegram.alertBanned(account);
    } else if (result.status === STATUS.INVALID_CREDENTIALS) {
      await telegram.alertInvalidCredentials(account);
    } else if (result.status === STATUS.ACTIVE && (oldStatus === STATUS.BANNED || oldStatus === STATUS.INVALID_CREDENTIALS)) {
      await telegram.alertRecovered(account);
    }
  }

  return { ...account, status: result.status, message: result.message, last_checked: now };
}

async function checkAllAccounts() {
  const accounts = db.prepare(`SELECT * FROM accounts`).all();
  const results = [];
  let newBans = 0;
  let recovered = 0;

  for (const account of accounts) {
    try {
      const rawResult = await checkAccount(account);
      const result = normalizeCheckResult(account, rawResult);
      const oldStatus = account.status;
      const now = new Date().toISOString();

      db.prepare(`UPDATE accounts SET status = ?, last_checked = ?, updated_at = ? WHERE id = ?`)
        .run(result.status, now, now, account.id);

      db.prepare(`INSERT INTO check_logs (account_id, status, message) VALUES (?, ?, ?)`)
        .run(account.id, result.status, result.message);

      if (oldStatus !== result.status && oldStatus !== 'unknown') {
        if (result.status === STATUS.BANNED) {
          await telegram.alertBanned(account);
          newBans++;
        } else if (result.status === STATUS.INVALID_CREDENTIALS) {
          await telegram.alertInvalidCredentials(account);
        } else if (result.status === STATUS.ACTIVE && (oldStatus === STATUS.BANNED || oldStatus === STATUS.INVALID_CREDENTIALS)) {
          await telegram.alertRecovered(account);
          recovered++;
        }
      }

      results.push({ id: account.id, email: account.email, ...result });

      // Delay between checks
      if (accounts.indexOf(account) < accounts.length - 1) {
        const delay = 2000 + Math.random() * 3000;
        await new Promise(resolve => setTimeout(resolve, delay));
      }
    } catch (err) {
      results.push({ id: account.id, email: account.email, status: STATUS.ERROR, message: err.message });
    }
  }

  console.log(`[Checker] Checked ${accounts.length} accounts. New bans: ${newBans}, Recovered: ${recovered}`);
  return results;
}

function getStats() {
  const total = db.prepare(`SELECT COUNT(*) as count FROM accounts`).get().count;
  const active = db.prepare(`SELECT COUNT(*) as count FROM accounts WHERE status = 'active'`).get().count;
  const banned = db.prepare(`SELECT COUNT(*) as count FROM accounts WHERE status = 'banned'`).get().count;
  const invalid = db.prepare(`SELECT COUNT(*) as count FROM accounts WHERE status = 'invalid_credentials'`).get().count;
  const unknown = db.prepare(`SELECT COUNT(*) as count FROM accounts WHERE status IN ('unknown', 'no_password', 'error', 'rate_limited')`).get().count;
  const invites = db.prepare(`SELECT COALESCE(SUM(invited_count),0) as used, COALESCE(SUM(invite_total),0) as total FROM accounts`).get();

  return {
    total,
    active,
    banned,
    invalid,
    unknown,
    invitesUsed: invites.used,
    invitesTotal: invites.total,
  };
}

module.exports = {
  checkSingleAccount,
  checkAllAccounts,
  getStats,
  startOAuthFlow,
  exchangeCodeForTokens,
  waitForOAuthCallback,
  checkWithToken,
  refreshAccessToken,
  STATUS,
};

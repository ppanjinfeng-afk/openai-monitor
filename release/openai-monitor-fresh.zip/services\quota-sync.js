const db = require('../db');
const { getPuppeteer } = require('./inviter');

let syncInFlight = null;

function sleep(ms) {
  return new Promise(resolve => setTimeout(resolve, ms));
}

function nowIso() {
  return new Date().toISOString();
}

function updateAccountQuotaSync(accountId, changes) {
  const entries = Object.entries(changes).filter(([, value]) => value !== undefined);
  if (entries.length === 0) {
    return;
  }

  const assignments = entries.map(([field]) => `${field} = ?`);
  const values = entries.map(([, value]) => value);
  assignments.push("updated_at = datetime('now')");
  values.push(accountId);

  db.prepare(`
    UPDATE accounts
    SET ${assignments.join(', ')}
    WHERE id = ?
  `).run(...values);
}

function summarizeQuotaResults(results = []) {
  const synced = results.filter(item => item.success).length;
  const failed = results.filter(item => item.success === false && !item.skipped).length;
  const skipped = results.filter(item => item.skipped).length;
  const overQuota = results.filter(item => item.success && item.overQuota).length;

  return {
    total: results.length,
    synced,
    failed,
    skipped,
    overQuota,
  };
}

async function withQuotaPage(work) {
  const pptr = await getPuppeteer();
  const browser = await pptr.launch({
    headless: 'new',
    args: [
      '--no-sandbox',
      '--disable-setuid-sandbox',
      '--disable-blink-features=AutomationControlled',
      '--window-size=1280,800',
    ],
    defaultViewport: { width: 1280, height: 800 },
  });

  try {
    const page = await browser.newPage();
    await page.setUserAgent(
      'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/131.0.0.0 Safari/537.36'
    );
    await page.goto('https://chatgpt.com/', {
      waitUntil: 'networkidle2',
      timeout: 30000,
    });
    await sleep(2000);

    return await work(page);
  } finally {
    await browser.close().catch(() => {});
  }
}

async function fetchQuotaUsage(page, account) {
  return await page.evaluate(async ({ accessToken }) => {
    const isUuid = (value) => /^[0-9a-fA-F]{8}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{12}$/.test(value);

    const getHeaders = (workspaceId, extraHeaders = {}) => {
      const headers = {
        Authorization: `Bearer ${accessToken}`,
        Accept: 'application/json',
        'OAI-Language': 'en-US',
      };

      if (workspaceId) {
        headers['ChatGPT-Account-Id'] = workspaceId;
      }

      return { ...headers, ...extraHeaders };
    };

    const parseResponse = async (response) => {
      const text = await response.text();
      try {
        return { text, data: JSON.parse(text) };
      } catch {
        return { text, data: null };
      }
    };

    const extractErrorMessage = (payload, fallbackText, status) => {
      const candidates = [
        payload?.error_description,
        payload?.message,
        payload?.detail,
        payload?.error?.message,
        payload?.error,
      ];

      for (const candidate of candidates) {
        if (candidate == null) {
          continue;
        }

        if (typeof candidate === 'string' && candidate.trim()) {
          return candidate.trim();
        }

        try {
          const json = JSON.stringify(candidate);
          if (json && json !== 'null') {
            return json;
          }
        } catch {}
      }

      return fallbackText || `HTTP ${status}`;
    };

    const fetchWorkspace = async () => {
      const response = await fetch(
        'https://chatgpt.com/backend-api/accounts/check/v4-2023-04-27?server_time=true',
        { headers: getHeaders(null) }
      );
      const parsed = await parseResponse(response);

      if (!response.ok) {
        return {
          success: false,
          message: `Failed to fetch workspaces (HTTP ${response.status}): ${extractErrorMessage(parsed.data, parsed.text, response.status)}`,
        };
      }

      const entries = Object.entries(parsed.data?.accounts || {});
      const workspaceEntry =
        entries.find(([accountId, details]) => details?.is_workspace && isUuid(accountId)) ||
        entries.find(([accountId, details]) => details?.is_personal === false && isUuid(accountId)) ||
        entries.find(([accountId]) => isUuid(accountId));

      if (!workspaceEntry) {
        return {
          success: false,
          message: 'No workspace account id found',
        };
      }

      return {
        success: true,
        workspaceId: workspaceEntry[0],
        workspace: workspaceEntry[1],
      };
    };

    const fetchUsers = async (workspaceId) => {
      const limit = 100;
      let offset = 0;
      let usedSeats = 0;
      let totalUsers = 0;

      while (true) {
        const response = await fetch(
          `https://chatgpt.com/backend-api/accounts/${workspaceId}/users?limit=${limit}&offset=${offset}`,
          { headers: getHeaders(workspaceId) }
        );
        const parsed = await parseResponse(response);

        if (!response.ok) {
          return {
            success: false,
            message: `Failed to fetch users (HTTP ${response.status}): ${extractErrorMessage(parsed.data, parsed.text, response.status)}`,
          };
        }

        const items = Array.isArray(parsed.data?.items) ? parsed.data.items : [];
        const total = Number(parsed.data?.total || items.length || 0);

        totalUsers = total;
        usedSeats += items.filter(item => item?.seat_type === 'default' && !item?.deactivated_time).length;

        offset += items.length;
        if (items.length === 0 || offset >= total) {
          break;
        }
      }

      return { success: true, usedSeats, totalUsers };
    };

    const fetchPendingInvites = async (workspaceId) => {
      const response = await fetch(
        `https://chatgpt.com/backend-api/accounts/${workspaceId}/invites?limit=100`,
        { headers: getHeaders(workspaceId) }
      );
      const parsed = await parseResponse(response);

      if (!response.ok) {
        return {
          success: false,
          message: `Failed to fetch invites (HTTP ${response.status}): ${extractErrorMessage(parsed.data, parsed.text, response.status)}`,
        };
      }

      const total = Number(parsed.data?.total || 0);
      return { success: true, pendingInvites: total };
    };

    const workspaceResult = await fetchWorkspace();
    if (!workspaceResult.success) {
      return workspaceResult;
    }

    const usersResult = await fetchUsers(workspaceResult.workspaceId);
    if (!usersResult.success) {
      return usersResult;
    }

    const invitesResult = await fetchPendingInvites(workspaceResult.workspaceId);
    if (!invitesResult.success) {
      return invitesResult;
    }

    return {
      success: true,
      workspaceId: workspaceResult.workspaceId,
      workspaceName: workspaceResult.workspace?.account?.name || '',
      usedSeats: usersResult.usedSeats + invitesResult.pendingInvites,
      memberSeats: usersResult.usedSeats,
      totalUsers: usersResult.totalUsers,
      pendingInvites: invitesResult.pendingInvites,
      planType: workspaceResult.workspace?.account?.plan_type || '',
    };
  }, {
    accessToken: account.access_token,
  });
}

async function syncSingleAccountUsage(accountId, options = {}) {
  const account = typeof accountId === 'object'
    ? accountId
    : db.prepare('SELECT * FROM accounts WHERE id = ?').get(accountId);

  if (!account) {
    throw new Error('Account not found');
  }

  if (!account.access_token || account.status !== 'active') {
    const message = 'Skipped quota sync because account is not active or not authorized';
    updateAccountQuotaSync(account.id, {
      quota_sync_status: 'skipped',
      quota_sync_message: message,
      quota_last_synced_at: nowIso(),
    });

    return {
      success: false,
      skipped: true,
      accountId: account.id,
      email: account.email,
      message,
    };
  }

  updateAccountQuotaSync(account.id, {
    quota_sync_status: 'running',
    quota_sync_message: 'Sync in progress',
    quota_last_synced_at: nowIso(),
  });

  let result;

  try {
    const page = options.page;
    result = page
      ? await fetchQuotaUsage(page, account)
      : await withQuotaPage(async innerPage => fetchQuotaUsage(innerPage, account));
  } catch (err) {
    updateAccountQuotaSync(account.id, {
      quota_sync_status: 'error',
      quota_sync_message: err.message,
      quota_last_synced_at: nowIso(),
    });

    return {
      success: false,
      accountId: account.id,
      email: account.email,
      message: err.message,
    };
  }

  if (!result.success) {
    updateAccountQuotaSync(account.id, {
      quota_sync_status: 'error',
      quota_sync_message: result.message,
      quota_last_synced_at: nowIso(),
    });

    return {
      success: false,
      accountId: account.id,
      email: account.email,
      message: result.message,
    };
  }

  const inviteTotal = Number(account.invite_total || 0);
  const remainingSeats = inviteTotal - result.usedSeats;
  const overQuota = result.usedSeats > inviteTotal;
  const message = `Synced members=${result.memberSeats}, pending=${result.pendingInvites}, used=${result.usedSeats}`;

  updateAccountQuotaSync(account.id, {
    invited_count: result.usedSeats,
    quota_member_seats: result.memberSeats,
    quota_pending_invites: result.pendingInvites,
    quota_total_users: result.totalUsers,
    quota_workspace_id: result.workspaceId || '',
    quota_workspace_name: result.workspaceName || '',
    quota_plan_type: result.planType || '',
    quota_sync_status: 'success',
    quota_sync_message: message,
    quota_last_synced_at: nowIso(),
  });

  return {
    success: true,
    accountId: account.id,
    email: account.email,
    usedSeats: result.usedSeats,
    memberSeats: result.memberSeats,
    pendingInvites: result.pendingInvites,
    totalUsers: result.totalUsers,
    workspaceId: result.workspaceId,
    workspaceName: result.workspaceName,
    planType: result.planType,
    inviteTotal,
    remainingSeats,
    overQuota,
    message,
  };
}

async function syncAllAccountUsage() {
  if (syncInFlight) {
    return syncInFlight;
  }

  syncInFlight = withQuotaPage(async page => {
    const accounts = db.prepare(`
      SELECT *
      FROM accounts
      WHERE status = 'active'
        AND access_token IS NOT NULL
        AND access_token != ''
      ORDER BY id ASC
    `).all();

    const results = [];

    for (const account of accounts) {
      try {
        const result = await syncSingleAccountUsage(account, { page });
        results.push(result);
      } catch (err) {
        results.push({
          success: false,
          accountId: account.id,
          email: account.email,
          message: err.message,
        });
      }

      await sleep(400);
    }

    const summary = summarizeQuotaResults(results);
    console.log(
      `[QuotaSync] Synced ${summary.synced}/${accounts.length} active accounts, failed ${summary.failed}, over quota ${summary.overQuota}`
    );
    return results;
  });

  try {
    return await syncInFlight;
  } finally {
    syncInFlight = null;
  }
}

module.exports = {
  syncAllAccountUsage,
  syncSingleAccountUsage,
  summarizeQuotaResults,
};

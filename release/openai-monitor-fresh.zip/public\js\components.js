// UI Components

const Components = {
  statusLabels: {
    active: '活跃',
    banned: '封禁',
    invalid_credentials: '凭证无效',
    rate_limited: '限流',
    error: '错误',
    unknown: '未知',
    no_password: '无密码',
  },

  quotaSyncLabels: {
    success: '同步成功',
    error: '同步失败',
    skipped: '已跳过',
    running: '同步中',
    never: '未同步',
  },

  statusBadge(status) {
    const label = this.statusLabels[status] || status;
    return `<span class="status-badge ${status}">${this.escapeHtml(label)}</span>`;
  },

  quotaSyncBadge(status) {
    const normalized = status || 'never';
    const label = this.quotaSyncLabels[normalized] || normalized;
    return `<span class="quota-sync-badge ${normalized}">${this.escapeHtml(label)}</span>`;
  },

  shortId(value) {
    if (!value) return '';
    const str = String(value);
    if (str.length <= 16) return str;
    return `${str.slice(0, 8)}...${str.slice(-6)}`;
  },

  inviteModeLabel(invite) {
    return invite.delivery_type === 'resend' ? '补发' : '发送';
  },

  quotaPill(label, tone = 'neutral', title = '') {
    const titleAttr = title ? ` title="${this.escapeHtml(title)}"` : '';
    return `<span class="quota-pill ${tone}"${titleAttr}>${this.escapeHtml(label)}</span>`;
  },

  inviteProgress(used, total) {
    const safeUsed = Number(used || 0);
    const safeTotal = Number(total || 0);
    const rawPct = safeTotal > 0 ? (safeUsed / safeTotal * 100) : 0;
    const pct = Math.max(0, Math.min(rawPct, 100));

    let level = 'low';
    if (safeUsed > safeTotal) level = 'over';
    else if (rawPct >= 75) level = 'high';
    else if (rawPct >= 50) level = 'medium';

    return `
      <div class="invite-progress">
        <div class="invite-bar">
          <div class="invite-bar-fill ${level}" style="width:${pct}%"></div>
        </div>
        <span class="invite-text ${level === 'over' ? 'over' : ''}">${safeUsed}/${safeTotal}</span>
      </div>
    `;
  },

  parseDate(dateStr) {
    if (!dateStr) return null;

    const value = String(dateStr).trim();
    if (!value) return null;

    const normalized = value.includes('T') ? value : value.replace(' ', 'T');
    const hasTimezone = /(?:Z|[+-]\d\d:\d\d)$/i.test(normalized);
    const date = new Date(hasTimezone ? normalized : `${normalized}Z`);
    return Number.isNaN(date.getTime()) ? null : date;
  },

  timeAgo(dateStr) {
    const date = this.parseDate(dateStr);
    if (!date) return '从未';

    const now = new Date();
    const diff = Math.floor((now - date) / 1000);

    if (diff < 60) return '刚刚';
    if (diff < 3600) return `${Math.floor(diff / 60)} 分钟前`;
    if (diff < 86400) return `${Math.floor(diff / 3600)} 小时前`;
    if (diff < 604800) return `${Math.floor(diff / 86400)} 天前`;
    return date.toLocaleDateString('zh-CN');
  },

  quotaBreakdown(account) {
    const used = Number(account.invited_count || 0);
    const total = Number(account.invite_total || 0);
    const members = Number(account.quota_member_seats || 0);
    const pending = Number(account.quota_pending_invites || 0);
    const remaining = total - used;
    const pills = [
      this.quotaPill(`已用 ${used}`),
      this.quotaPill(`成员 ${members}`),
      this.quotaPill(`待接受 ${pending}`, pending > 0 ? 'accent' : 'neutral'),
    ];

    if (remaining < 0) {
      pills.push(this.quotaPill(`超额 ${Math.abs(remaining)}`, 'danger'));
    } else if (remaining === 0) {
      pills.push(this.quotaPill('已满', 'warning'));
    } else {
      pills.push(this.quotaPill(`剩余 ${remaining}`, remaining <= 1 ? 'warning' : 'success'));
    }

    return `<div class="quota-breakdown">${pills.join('')}</div>`;
  },

  quotaSyncMeta(account) {
    const syncTime = this.timeAgo(account.quota_last_synced_at);
    const message = account.quota_sync_message || '';
    const workspaceBits = [];

    if (account.quota_workspace_name) {
      workspaceBits.push(account.quota_workspace_name);
    }
    if (account.quota_plan_type) {
      workspaceBits.push(account.quota_plan_type);
    }

    return `
      <div class="sync-meta">
        <span class="text-muted">检查: ${this.timeAgo(account.last_checked)}</span>
        <div class="quota-sync-line">
          ${this.quotaSyncBadge(account.quota_sync_status)}
          <span class="text-muted">配额: ${syncTime}</span>
        </div>
        ${workspaceBits.length > 0 ? `<span class="text-muted quota-sync-extra">${this.escapeHtml(workspaceBits.join(' · '))}</span>` : ''}
        ${message ? `<span class="quota-sync-message" title="${this.escapeHtml(message)}">${this.escapeHtml(message)}</span>` : ''}
      </div>
    `;
  },

  accountRow(account) {
    const used = Number(account.invited_count || 0);
    const total = Number(account.invite_total || 0);
    const rowClasses = [];

    if (used > total) {
      rowClasses.push('over-quota-row');
    }
    if (account.quota_sync_status === 'error') {
      rowClasses.push('quota-sync-error-row');
    }

    return `
      <tr data-id="${account.id}" class="${rowClasses.join(' ')}">
        <td><input type="checkbox" class="account-checkbox" data-id="${account.id}"></td>
        <td>
          <div style="display:flex;flex-direction:column">
            <span style="font-weight:500">${this.escapeHtml(account.email)}</span>
            ${account.password ? '<span class="text-muted" style="font-size:0.75rem">已配置密码</span>' : ''}
            ${account.access_token ? '<span class="text-muted" style="font-size:0.75rem;color:var(--green)">已授权</span>' : '<span class="text-muted" style="font-size:0.75rem;color:var(--yellow)">未授权</span>'}
          </div>
        </td>
        <td><span class="text-muted">${this.escapeHtml(account.label || '-')}</span></td>
        <td>${this.statusBadge(account.status)}</td>
        <td>
          <div class="quota-cell">
            ${this.inviteProgress(account.invited_count, account.invite_total)}
            ${this.quotaBreakdown(account)}
          </div>
        </td>
        <td>${this.quotaSyncMeta(account)}</td>
        <td>
          <div class="action-btns">
            <button class="action-btn" title="发送邀请" onclick="App.openInviteModal(${account.id})" style="color:var(--blue)">
              <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M4 4h16c1.1 0 2 .9 2 2v12c0 1.1-.9 2-2 2H4c-1.1 0-2-.9-2-2V6c0-1.1.9-2 2-2z"/><polyline points="22,6 12,13 2,6"/></svg>
            </button>
            <button class="action-btn" title="同步名额" onclick="App.syncAccountQuota(${account.id})" style="color:var(--purple)">
              <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M21 2v6h-6"/><path d="M3 22v-6h6"/><path d="M20.49 9A9 9 0 0 0 5.64 5.64L3 8"/><path d="M3.51 15a9 9 0 0 0 14.85 3.36L21 16"/></svg>
            </button>
            <button class="action-btn" title="账号授权" onclick="App.oauthAccount(${account.id})" style="color:var(--green)">
              <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><rect x="3" y="11" width="18" height="11" rx="2" ry="2"/><path d="M7 11V7a5 5 0 0 1 10 0v4"/></svg>
            </button>
            <button class="action-btn" title="编辑" onclick="App.editAccount(${account.id})">
              <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M11 4H4a2 2 0 0 0-2 2v14a2 2 0 0 0 2 2h14a2 2 0 0 0 2-2v-7"/><path d="M18.5 2.5a2.121 2.121 0 0 1 3 3L12 15l-4 1 1-4 9.5-9.5z"/></svg>
            </button>
            <button class="action-btn" title="立即检查" onclick="App.checkSingle(${account.id})">
              <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><polyline points="23 4 23 10 17 10"/><polyline points="1 20 1 14 7 14"/><path d="M3.51 9a9 9 0 0 1 14.85-3.36L23 10M1 14l4.64 4.36A9 9 0 0 0 20.49 15"/></svg>
            </button>
            <button class="action-btn danger" title="删除" onclick="App.deleteAccount(${account.id})">
              <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><polyline points="3 6 5 6 21 6"/><path d="M19 6v14a2 2 0 0 1-2 2H7a2 2 0 0 1-2-2V6m3 0V4a2 2 0 0 1 2-2h4a2 2 0 0 1 2 2v2"/></svg>
            </button>
          </div>
        </td>
      </tr>
    `;
  },

  logEntry(log) {
    return `
      <div class="log-entry">
        <div class="log-dot ${log.status}"></div>
        <div class="log-info">
          <div class="log-email">${this.escapeHtml(log.email || '')} ${log.label ? `<span class="text-muted">(${this.escapeHtml(log.label)})</span>` : ''}</div>
          <div class="log-message">${this.escapeHtml(log.message || '')}</div>
        </div>
        <div class="log-time">${this.timeAgo(log.checked_at)}</div>
      </div>
    `;
  },

  inviteRow(invite) {
    const requestedAccountEmail = invite.requested_account_email || '';
    const fallbackFromAccountEmail = invite.fallback_from_account_email || '';
    const showRequested = requestedAccountEmail && requestedAccountEmail !== invite.account_email;
    const remoteInviteId = invite.remote_invite_id || invite.remoteInviteId || '';

    return `
      <tr data-id="${invite.id}">
        <td><span style="font-weight:500">${this.escapeHtml(invite.target_email)}</span></td>
        <td>
          <div style="display:flex;flex-direction:column">
            <span style="font-size:0.85rem; font-weight:500">${this.escapeHtml(invite.account_email)}</span>
            <span class="text-muted" style="font-size:0.75rem">${this.escapeHtml(invite.account_label || '')}</span>
            ${showRequested ? `<span class="text-muted" style="font-size:0.75rem">请求账号: ${this.escapeHtml(requestedAccountEmail)}</span>` : ''}
            ${fallbackFromAccountEmail ? `<span class="text-muted" style="font-size:0.75rem; color:var(--yellow)">回退自: ${this.escapeHtml(fallbackFromAccountEmail)}</span>` : ''}
          </div>
        </td>
        <td>
          <div style="display:flex;flex-direction:column">
            ${this.statusBadge(invite.status)}
            <div style="display:flex; gap:6px; flex-wrap:wrap; margin-top:6px;">
              <span class="text-muted" style="font-size:0.72rem; background:var(--bg-secondary); padding:2px 6px; border-radius:999px;">模式: ${this.escapeHtml(this.inviteModeLabel(invite))}</span>
              ${remoteInviteId ? `<span class="text-muted" style="font-size:0.72rem; background:var(--bg-secondary); padding:2px 6px; border-radius:999px;" title="${this.escapeHtml(remoteInviteId)}">远端ID: ${this.escapeHtml(this.shortId(remoteInviteId))}</span>` : ''}
            </div>
            <span class="text-muted" style="font-size:0.75rem; max-width: 200px; white-space: nowrap; overflow: hidden; text-overflow: ellipsis;" title="${this.escapeHtml(invite.message)}">${this.escapeHtml(invite.message)}</span>
          </div>
        </td>
        <td><span class="text-muted">${this.timeAgo(invite.updated_at || invite.created_at)}</span></td>
        <td>
          <div class="action-btns">
            <button class="action-btn" title="补发邀请" onclick="App.resendInvite(${invite.account_id}, '${this.escapeHtml(invite.target_email)}')" style="color:var(--blue)">
              <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><polyline points="1 4 1 10 7 10"/><polyline points="23 20 23 14 17 14"/><path d="M20.49 9A9 9 0 0 0 5.64 5.64L1 10m22 4l-4.64 4.36A9 9 0 0 1 3.51 15"/></svg>
            </button>
            <button class="action-btn danger" title="删除记录" onclick="App.deleteInvite(${invite.id})">
              <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><polyline points="3 6 5 6 21 6"/><path d="M19 6v14a2 2 0 0 1-2 2H7a2 2 0 0 1-2-2V6m3 0V4a2 2 0 0 1 2-2h4a2 2 0 0 1 2 2v2"/></svg>
            </button>
          </div>
        </td>
      </tr>
    `;
  },

  addAccountModal(account = null) {
    const isEdit = !!account;
    return `
      <form id="account-form">
        <div class="form-group">
          <label for="acc-email">邮箱 *</label>
          <input type="email" id="acc-email" class="form-input" required value="${isEdit ? this.escapeHtml(account.email) : ''}" placeholder="account@example.com">
        </div>
        <div class="form-group">
          <label for="acc-password">密码</label>
          <input type="password" id="acc-password" class="form-input" value="${isEdit ? this.escapeHtml(account.password) : ''}" placeholder="可选">
        </div>
        <div class="form-group">
          <label for="acc-label">标签</label>
          <input type="text" id="acc-label" class="form-input" value="${isEdit ? this.escapeHtml(account.label) : ''}" placeholder="备注">
        </div>
        <div class="form-group">
          <label for="acc-invite-link">邀请链接</label>
          <input type="text" id="acc-invite-link" class="form-input" value="${isEdit ? this.escapeHtml(account.invite_link) : ''}" placeholder="https://...">
        </div>
        <div style="display:grid; grid-template-columns:1fr 1fr; gap:12px;">
          <div class="form-group">
            <label for="acc-invite-total">本地总名额</label>
            <input type="number" id="acc-invite-total" class="form-input" min="0" max="100" value="${isEdit ? account.invite_total : 4}">
          </div>
          <div class="form-group">
            <label for="acc-invited-count">已用名额</label>
            <input type="number" id="acc-invited-count" class="form-input" min="0" max="100" value="${isEdit ? account.invited_count : 0}">
          </div>
        </div>
        <div class="form-actions">
          <button type="button" class="btn btn-secondary" onclick="App.closeModal()">取消</button>
          <button type="submit" class="btn btn-primary">${isEdit ? '保存更改' : '添加账号'}</button>
        </div>
      </form>
    `;
  },

  importModal() {
    return `
      <div>
        <p style="font-size:0.88rem; color:var(--text-secondary); margin-bottom:16px;">
          支持 JSON 或 CSV 导入，每行一个账号。
        </p>
        <textarea class="import-textarea" id="import-data" placeholder='[
  { "email": "user1@example.com", "password": "pass123", "label": "账号1" },
  { "email": "user2@example.com", "password": "pass456", "label": "账号2" }
]

或：
email,password,label
user1@example.com,pass123,账号1
user2@example.com,pass456,账号2'></textarea>
        <div class="form-actions">
          <button type="button" class="btn btn-secondary" onclick="App.closeModal()">取消</button>
          <button type="button" class="btn btn-primary" onclick="App.handleImport()">导入</button>
        </div>
      </div>
    `;
  },

  escapeHtml(value) {
    const div = document.createElement('div');
    div.textContent = value == null ? '' : String(value);
    return div.innerHTML;
  },

  inviteModal(accountId) {
    return `
      <div>
        <p style="font-size:0.88rem; color:var(--text-secondary); margin-bottom:16px;">
          为账号 #${accountId} 发送官方团队邀请，后台会自动打开浏览器并调用上游接口。
        </p>
        <div class="form-group">
          <label for="invite-email">目标邮箱 *</label>
          <input type="email" id="invite-email" class="form-input" placeholder="someone@example.com" required>
        </div>
        <div class="form-actions" style="margin-top:20px">
          <button type="button" class="btn btn-secondary" onclick="App.closeModal()">取消</button>
          <button type="button" class="btn btn-primary" id="btn-submit-invite" onclick="App.handleSendInvite(${accountId})">发送邀请</button>
        </div>
      </div>
    `;
  },

  autoInviteModal() {
    return `
      <div>
        <p style="font-size:0.88rem; color:var(--text-secondary); margin-bottom:16px;">
          输入一个目标邮箱，系统会自动选择有剩余名额的可用账号发送邀请。
        </p>
        <div class="form-group">
          <label for="auto-invite-email">目标邮箱 *</label>
          <input type="email" id="auto-invite-email" class="form-input" placeholder="someone@example.com" required>
        </div>
        <div class="form-actions" style="margin-top:20px">
          <button type="button" class="btn btn-secondary" onclick="App.closeModal()">取消</button>
          <button type="button" class="btn btn-primary" id="btn-submit-auto-invite" onclick="App.handleAutoInvite()">自动邀请</button>
        </div>
      </div>
    `;
  },

  bulkAutoInviteModal() {
    return `
      <div>
        <p style="font-size:0.88rem; color:var(--text-secondary); margin-bottom:16px;">
          粘贴多个邮箱，前端会排队逐个分配可用账号发送邀请。
        </p>
        <div class="form-group">
          <label for="bulk-invite-emails">目标邮箱 *</label>
          <textarea id="bulk-invite-emails" class="form-input" rows="6" placeholder="a@a.com&#10;b@b.com" required></textarea>
        </div>

        <div id="bulk-invite-progress-container" class="hidden" style="margin-top:20px; border-top: 1px solid var(--border); padding-top: 16px;">
          <h4 style="margin-bottom:8px; font-size:0.9rem;">发送进度 <span id="bulk-invite-status-text">0 / 0</span></h4>

          <div style="background: var(--bg-secondary); border-radius:4px; height:8px; width:100%; margin-bottom:12px; overflow:hidden;">
            <div id="bulk-invite-progress-bar" style="background: var(--blue); height:100%; width:0%; transition: width 0.3s;"></div>
          </div>

          <div id="bulk-invite-logs" style="max-height: 150px; overflow-y: auto; background: var(--bg-dark); border: 1px solid var(--border); border-radius: 4px; padding: 8px; font-size: 0.8rem; font-family: monospace;">
          </div>
        </div>

        <div class="form-actions" style="margin-top:20px">
          <button type="button" class="btn btn-secondary" id="btn-bulk-cancel" onclick="App.closeModal()">取消</button>
          <button type="button" class="btn btn-primary" id="btn-submit-bulk-invite" onclick="App.handleBulkAutoInvite()">开始批量邀请</button>
        </div>
      </div>
    `;
  },
};

let puppeteer;
let StealthPlugin;

async function getPuppeteer() {
  if (!puppeteer) {
    puppeteer = require('puppeteer-extra');
    StealthPlugin = require('puppeteer-extra-plugin-stealth');
    puppeteer.use(StealthPlugin());
  }
  return puppeteer;
}

async function sendTeamInvite(account, targetEmail, options = {}) {
  const trimmedEmail = String(targetEmail || '').trim();
  if (!trimmedEmail) {
    return { success: false, message: 'Target email is required' };
  }

  if (!account.access_token) {
    return { success: false, message: 'Account is not authorized yet' };
  }

  let browser = null;

  try {
    const pptr = await getPuppeteer();
    browser = await pptr.launch({
      headless: 'new',
      args: [
        '--no-sandbox',
        '--disable-setuid-sandbox',
        '--disable-blink-features=AutomationControlled',
        '--window-size=1280,800',
      ],
      defaultViewport: { width: 1280, height: 800 },
    });

    const page = await browser.newPage();
    await page.setUserAgent(
      'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/131.0.0.0 Safari/537.36'
    );

    console.log(`[Inviter] Opening chatgpt.com for ${account.email}...`);
    await page.goto('https://chatgpt.com/', {
      waitUntil: 'networkidle2',
      timeout: 30000,
    });
    await new Promise(resolve => setTimeout(resolve, 3000));

    const result = await page.evaluate(async ({ accessToken, emailToInvite, forceResend }) => {
      const DUPLICATE_HINTS = [
        'already invited',
        'already been invited',
        'already exists',
        'already pending',
        'already a member',
        'already sent',
        'duplicate',
      ];

      const sleep = (ms) => new Promise(resolve => setTimeout(resolve, ms));
      const isUuid = (value) => /^[0-9a-fA-F]{8}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{12}$/.test(value);
      const normalizeEmail = (value) => String(value || '').trim().toLowerCase();

      const getHeaders = (workspaceId, extraHeaders = {}) => {
        const headers = {
          Authorization: `Bearer ${accessToken}`,
          Accept: 'application/json',
          'OAI-Language': 'en-US',
        };

        if (workspaceId) {
          headers['ChatGPT-Account-Id'] = workspaceId;
        }

        return { ...headers, ...extraHeaders };
      };

      const parseResponse = async (response) => {
        const text = await response.text();
        try {
          return { text, data: JSON.parse(text) };
        } catch {
          return { text, data: null };
        }
      };

      const stringifyValue = (value) => {
        if (value == null) {
          return '';
        }
        if (typeof value === 'string') {
          return value;
        }
        try {
          return JSON.stringify(value);
        } catch {
          return String(value);
        }
      };

      const extractErrorMessage = (payload) => {
        if (!payload) {
          return '';
        }

        const candidates = [
          payload.error_description,
          payload.message,
          payload.detail,
          payload.error && payload.error.message,
          payload.error,
          payload.details,
        ];

        for (const candidate of candidates) {
          const value = stringifyValue(candidate).trim();
          if (value) {
            return value;
          }
        }

        return '';
      };

      const extractErroredEmailMessage = (payload, emailAddress) => {
        const erroredEmails = Array.isArray(payload?.errored_emails) ? payload.errored_emails : [];

        for (const entry of erroredEmails) {
          if (typeof entry === 'string') {
            if (!emailAddress || normalizeEmail(entry) === normalizeEmail(emailAddress)) {
              return entry;
            }
            continue;
          }

          if (!entry || typeof entry !== 'object') {
            continue;
          }

          const entryEmail = entry.email_address || entry.email || entry.address || '';
          if (emailAddress && entryEmail && normalizeEmail(entryEmail) !== normalizeEmail(emailAddress)) {
            continue;
          }

          const message = extractErrorMessage(entry) || stringifyValue(entry);
          if (message) {
            return message;
          }
        }

        return '';
      };

      const getWorkspaceId = async () => {
        const accountsRes = await fetch(
          'https://chatgpt.com/backend-api/accounts/check/v4-2023-04-27?server_time=true',
          { headers: getHeaders(null) }
        );
        const parsed = await parseResponse(accountsRes);

        if (!accountsRes.ok) {
          return {
            error: `Failed to fetch workspaces (HTTP ${accountsRes.status}): ${extractErrorMessage(parsed.data) || parsed.text}`,
          };
        }

        const accountsData = parsed.data || {};
        const entries = Object.entries(accountsData.accounts || {});
        let workspaceId = null;

        for (const [accountId, details] of entries) {
          if (details && details.is_workspace && isUuid(accountId)) {
            workspaceId = accountId;
            break;
          }
        }

        if (!workspaceId) {
          for (const [accountId, details] of entries) {
            if (details && details.is_personal === false && isUuid(accountId)) {
              workspaceId = accountId;
              break;
            }
          }
        }

        if (!workspaceId) {
          for (const [accountId] of entries) {
            if (isUuid(accountId)) {
              workspaceId = accountId;
              break;
            }
          }
        }

        if (!workspaceId) {
          return {
            error: `No workspace account id found in ${JSON.stringify(entries.map(([accountId]) => accountId))}`,
          };
        }

        return { workspaceId };
      };

      const listInvites = async (workspaceId) => {
        const listRes = await fetch(
          `https://chatgpt.com/backend-api/accounts/${workspaceId}/invites`,
          { headers: getHeaders(workspaceId) }
        );
        const parsed = await parseResponse(listRes);

        if (!listRes.ok) {
          return {
            success: false,
            code: 'invite_lookup_failed',
            message: `Failed to list invites (HTTP ${listRes.status}): ${extractErrorMessage(parsed.data) || parsed.text || `HTTP ${listRes.status}`}`,
          };
        }

        return {
          success: true,
          items: Array.isArray(parsed.data?.items) ? parsed.data.items : [],
        };
      };

      const findInviteByEmail = async (workspaceId, emailAddress) => {
        const listResult = await listInvites(workspaceId);
        if (!listResult.success) {
          return listResult;
        }

        const invite = listResult.items.find(item => normalizeEmail(item?.email_address) === normalizeEmail(emailAddress)) || null;
        return { success: true, invite };
      };

      const resendInviteById = async (workspaceId, inviteId) => {
        if (!inviteId) {
          return {
            success: false,
            code: 'invite_not_found',
            message: 'No remote invite id found to resend',
          };
        }

        const resendRes = await fetch(
          `https://chatgpt.com/backend-api/accounts/${workspaceId}/invites/${inviteId}`,
          {
            method: 'PATCH',
            headers: getHeaders(workspaceId, {
              'Content-Type': 'application/json',
            }),
            body: JSON.stringify({ resend: true }),
          }
        );
        const parsed = await parseResponse(resendRes);

        if (resendRes.ok && parsed.data?.success === true) {
          await sleep(1000);
          return { success: true };
        }

        return {
          success: false,
          code: 'resend_failed',
          message: `Failed to resend existing invite (HTTP ${resendRes.status}): ${extractErrorMessage(parsed.data) || parsed.text || `HTTP ${resendRes.status}`}`,
        };
      };

      const revokeInviteByEmail = async (workspaceId, emailAddress) => {
        const revokeRes = await fetch(
          `https://chatgpt.com/backend-api/accounts/${workspaceId}/invites`,
          {
            method: 'DELETE',
            headers: getHeaders(workspaceId, {
              'Content-Type': 'application/json',
            }),
            body: JSON.stringify({
              email_address: emailAddress,
            }),
          }
        );
        const parsed = await parseResponse(revokeRes);
        const message = extractErrorMessage(parsed.data) || parsed.text || `HTTP ${revokeRes.status}`;

        if (revokeRes.ok) {
          await sleep(1500);
          return { success: true, found: true };
        }

        if (revokeRes.status === 404 && message.toLowerCase().includes('invite not found')) {
          return { success: true, found: false };
        }

        return {
          success: false,
          code: 'revoke_failed',
          message: `Failed to revoke existing invite (HTTP ${revokeRes.status}): ${message}`,
        };
      };

      const createInvite = async (workspaceId) => {
        const inviteRes = await fetch(`https://chatgpt.com/backend-api/accounts/${workspaceId}/invites`, {
          method: 'POST',
          headers: getHeaders(workspaceId, {
            'Content-Type': 'application/json',
          }),
          body: JSON.stringify({
            email_addresses: [emailToInvite],
            role: 'standard-user',
          }),
        });
        const parsed = await parseResponse(inviteRes);

        const message = extractErrorMessage(parsed.data) || parsed.text || `HTTP ${inviteRes.status}`;
        const lowerMessage = message.toLowerCase();

        if (!inviteRes.ok) {
          return {
            success: false,
            code: 'create_failed',
            isDuplicate:
              inviteRes.status === 409 ||
              inviteRes.status === 422 ||
              DUPLICATE_HINTS.some(hint => lowerMessage.includes(hint)),
            message: `Failed to create invite (HTTP ${inviteRes.status}): ${message}`,
          };
        }

        const accountInvites = Array.isArray(parsed.data?.account_invites) ? parsed.data.account_invites : [];
        const matchingInvite = accountInvites.find(item => normalizeEmail(item?.email_address) === normalizeEmail(emailToInvite)) || null;

        if (matchingInvite) {
          return {
            success: true,
            createdNewInvite: true,
            invite: matchingInvite,
          };
        }

        const remoteInviteResult = await findInviteByEmail(workspaceId, emailToInvite);
        if (!remoteInviteResult.success) {
          return remoteInviteResult;
        }

        if (remoteInviteResult.invite) {
          return {
            success: true,
            createdNewInvite: true,
            invite: remoteInviteResult.invite,
          };
        }

        const erroredEmailMessage = extractErroredEmailMessage(parsed.data, emailToInvite);
        if (erroredEmailMessage) {
          return {
            success: false,
            code: 'create_failed',
            message: `Failed to create invite: ${erroredEmailMessage}`,
          };
        }

        return {
          success: false,
          code: 'invite_not_materialized',
          message: `OpenAI accepted the invite request but did not create a pending invite for ${emailToInvite}`,
        };
      };

      const workspaceResult = await getWorkspaceId();
      if (workspaceResult.error) {
        return { success: false, code: 'workspace_lookup_failed', message: workspaceResult.error };
      }

      const { workspaceId } = workspaceResult;
      const existingInviteResult = await findInviteByEmail(workspaceId, emailToInvite);
      if (!existingInviteResult.success) {
        return existingInviteResult;
      }

      if (forceResend && existingInviteResult.invite) {
        const resendResult = await resendInviteById(workspaceId, existingInviteResult.invite.id);
        if (!resendResult.success) {
          return resendResult;
        }

        return {
          success: true,
          wasResend: true,
          createdNewInvite: false,
          remoteInviteId: existingInviteResult.invite.id,
          message: `Invite resent successfully to ${emailToInvite}`,
        };
      }

      let createResult = await createInvite(workspaceId);

      if (!createResult.success && createResult.isDuplicate) {
        const duplicateInviteResult = await findInviteByEmail(workspaceId, emailToInvite);
        if (!duplicateInviteResult.success) {
          return duplicateInviteResult;
        }

        if (duplicateInviteResult.invite) {
          if (forceResend) {
            const resendResult = await resendInviteById(workspaceId, duplicateInviteResult.invite.id);
            if (!resendResult.success) {
              return resendResult;
            }

            return {
              success: true,
              wasResend: true,
              createdNewInvite: false,
              remoteInviteId: duplicateInviteResult.invite.id,
              message: `Invite resent successfully to ${emailToInvite}`,
            };
          }

          return {
            success: true,
            wasResend: false,
            createdNewInvite: false,
            remoteInviteId: duplicateInviteResult.invite.id,
            message: `Invite already pending for ${emailToInvite}`,
          };
        }

        const revokeResult = await revokeInviteByEmail(workspaceId, emailToInvite);
        if (!revokeResult.success) {
          return revokeResult;
        }

        if (revokeResult.found) {
          createResult = await createInvite(workspaceId);
        }
      }

      if (!createResult.success) {
        return createResult;
      }

      return {
        success: true,
        wasResend: forceResend,
        createdNewInvite: Boolean(createResult.createdNewInvite),
        remoteInviteId: createResult.invite?.id || null,
        message: forceResend
          ? `Invite resent successfully to ${emailToInvite}`
          : `Invite sent successfully to ${emailToInvite}`,
      };
    }, {
      accessToken: account.access_token,
      emailToInvite: trimmedEmail,
      forceResend: Boolean(options.forceResend),
    });

    return result;
  } catch (err) {
    console.error(`[Inviter] Error sending invite to ${trimmedEmail}:`, err);
    return { success: false, message: `Browser script failed: ${err.message}` };
  } finally {
    if (browser) {
      await browser.close().catch(() => {});
    }
  }
}

module.exports = {
  getPuppeteer,
  sendTeamInvite,
};

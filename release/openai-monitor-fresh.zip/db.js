const Database = require('better-sqlite3');
const path = require('path');
const fs = require('fs');

const dataDir = path.join(__dirname, 'data');
if (!fs.existsSync(dataDir)) {
  fs.mkdirSync(dataDir, { recursive: true });
}

const db = new Database(path.join(dataDir, 'monitor.db'));

// Enable WAL mode for better concurrent performance
db.pragma('journal_mode = WAL');

// Create tables
db.exec(`
  CREATE TABLE IF NOT EXISTS accounts (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    email TEXT NOT NULL,
    password TEXT DEFAULT '',
    access_token TEXT DEFAULT '',
    refresh_token TEXT DEFAULT '',
    label TEXT DEFAULT '',
    status TEXT DEFAULT 'unknown',
    invited_count INTEGER DEFAULT 0,
    invite_total INTEGER DEFAULT 4,
    invite_link TEXT DEFAULT '',
    last_checked TEXT,
    created_at TEXT DEFAULT (datetime('now')),
    updated_at TEXT DEFAULT (datetime('now'))
  );

  CREATE TABLE IF NOT EXISTS check_logs (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    account_id INTEGER NOT NULL,
    status TEXT NOT NULL,
    message TEXT DEFAULT '',
    checked_at TEXT DEFAULT (datetime('now')),
    FOREIGN KEY (account_id) REFERENCES accounts(id) ON DELETE CASCADE
  );

  CREATE TABLE IF NOT EXISTS invites (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    account_id INTEGER NOT NULL,
    target_email TEXT NOT NULL,
    status TEXT DEFAULT 'sent',
    message TEXT DEFAULT '',
    created_at TEXT DEFAULT (datetime('now')),
    updated_at TEXT DEFAULT (datetime('now')),
    FOREIGN KEY (account_id) REFERENCES accounts(id) ON DELETE CASCADE
  );

  CREATE TABLE IF NOT EXISTS settings (
    key TEXT PRIMARY KEY,
    value TEXT NOT NULL
  );
`);

function ensureColumn(tableName, columnName, definition) {
  const columns = db.prepare(`PRAGMA table_info(${tableName})`).all();
  if (!columns.some(column => column.name === columnName)) {
    db.exec(`ALTER TABLE ${tableName} ADD COLUMN ${definition}`);
  }
}

ensureColumn('invites', 'requested_account_id', 'requested_account_id INTEGER');
ensureColumn('invites', 'fallback_from_account_id', 'fallback_from_account_id INTEGER');
ensureColumn('invites', 'remote_invite_id', "remote_invite_id TEXT DEFAULT ''");
ensureColumn('invites', 'delivery_type', "delivery_type TEXT DEFAULT 'send'");
ensureColumn('accounts', 'quota_sync_status', "quota_sync_status TEXT DEFAULT 'never'");
ensureColumn('accounts', 'quota_sync_message', "quota_sync_message TEXT DEFAULT ''");
ensureColumn('accounts', 'quota_last_synced_at', 'quota_last_synced_at TEXT');
ensureColumn('accounts', 'quota_member_seats', 'quota_member_seats INTEGER DEFAULT 0');
ensureColumn('accounts', 'quota_pending_invites', 'quota_pending_invites INTEGER DEFAULT 0');
ensureColumn('accounts', 'quota_total_users', 'quota_total_users INTEGER DEFAULT 0');
ensureColumn('accounts', 'quota_workspace_id', "quota_workspace_id TEXT DEFAULT ''");
ensureColumn('accounts', 'quota_workspace_name', "quota_workspace_name TEXT DEFAULT ''");
ensureColumn('accounts', 'quota_plan_type', "quota_plan_type TEXT DEFAULT ''");

db.prepare(`
  UPDATE invites
  SET requested_account_id = account_id
  WHERE requested_account_id IS NULL
`).run();

db.prepare(`
  UPDATE invites
  SET delivery_type = CASE
    WHEN LOWER(COALESCE(message, '')) LIKE '%resent%' THEN 'resend'
    ELSE 'send'
  END
  WHERE delivery_type IS NULL
     OR TRIM(delivery_type) = ''
`).run();

db.prepare(`
  UPDATE accounts
  SET quota_sync_status = 'never'
  WHERE quota_sync_status IS NULL
     OR TRIM(quota_sync_status) = ''
`).run();

db.prepare(`
  UPDATE accounts
  SET quota_sync_message = ''
  WHERE quota_sync_message IS NULL
`).run();

db.prepare(`
  UPDATE accounts
  SET quota_member_seats = COALESCE(quota_member_seats, 0),
      quota_pending_invites = COALESCE(quota_pending_invites, 0),
      quota_total_users = COALESCE(quota_total_users, 0),
      quota_workspace_id = COALESCE(quota_workspace_id, ''),
      quota_workspace_name = COALESCE(quota_workspace_name, ''),
      quota_plan_type = COALESCE(quota_plan_type, '')
`).run();

// Insert default settings if not exist
const insertSetting = db.prepare(`INSERT OR IGNORE INTO settings (key, value) VALUES (?, ?)`);
const defaultSettings = [
  ['telegram_bot_token', ''],
  ['telegram_chat_id', ''],
  ['check_interval_minutes', '30'],
  ['alerts_enabled', 'true'],
  ['daily_summary_enabled', 'true'],
  ['daily_summary_hour', '9'],
];
const insertDefaults = db.transaction(() => {
  for (const [key, value] of defaultSettings) {
    insertSetting.run(key, value);
  }
});
insertDefaults();

module.exports = db;

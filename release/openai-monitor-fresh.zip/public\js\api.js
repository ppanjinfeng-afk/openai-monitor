// API Client for OpenAI Monitor

const API = {
  base: '',

  async request(url, options = {}) {
    const res = await fetch(this.base + url, {
      headers: { 'Content-Type': 'application/json', ...options.headers },
      ...options,
    });
    const data = await res.json();
    if (!res.ok) {
      throw new Error(data.error || `HTTP ${res.status}`);
    }
    return data;
  },

  // Accounts
  getAccounts(params = {}) {
    const qs = new URLSearchParams(params).toString();
    return this.request(`/api/accounts?${qs}`);
  },

  getStats() {
    return this.request('/api/accounts/stats');
  },

  syncAllQuotas() {
    return this.request('/api/accounts/sync-quotas', {
      method: 'POST',
    });
  },

  addAccount(data) {
    return this.request('/api/accounts', {
      method: 'POST',
      body: JSON.stringify(data),
    });
  },

  batchImport(accounts) {
    return this.request('/api/accounts/batch', {
      method: 'POST',
      body: JSON.stringify({ accounts }),
    });
  },

  updateAccount(id, data) {
    return this.request(`/api/accounts/${id}`, {
      method: 'PUT',
      body: JSON.stringify(data),
    });
  },

  syncAccountQuota(id) {
    return this.request(`/api/accounts/${id}/sync-quota`, {
      method: 'POST',
    });
  },

  inviteAccount(id, email, options = {}) {
    return this.request(`/api/accounts/${id}/invite`, {
      method: 'POST',
      body: JSON.stringify({ email, ...options }),
    });
  },

  autoInvite(email) {
    return this.request('/api/accounts/auto-invite', {
      method: 'POST',
      body: JSON.stringify({ email }),
    });
  },

  deleteAccount(id) {
    return this.request(`/api/accounts/${id}`, {
      method: 'DELETE',
    });
  },

  deleteAccounts(ids) {
    return this.request('/api/accounts', {
      method: 'DELETE',
      body: JSON.stringify({ ids }),
    });
  },

  getInvites(params = {}) {
    const qs = new URLSearchParams(params).toString();
    return this.request(`/api/invites?${qs}`);
  },

  deleteInvite(id) {
    return this.request(`/api/invites/${id}`, {
      method: 'DELETE',
    });
  },

  // Checks
  runCheckAll() {
    return this.request('/api/checks/run', { method: 'POST' });
  },

  checkAccount(id) {
    return this.request(`/api/checks/${id}`, { method: 'POST' });
  },

  getCheckStatus() {
    return this.request('/api/checks/status');
  },

  startOAuth(id) {
    return this.request(`/api/checks/oauth/start/${id}`, { method: 'POST' });
  },

  getLogs(params = {}) {
    const qs = new URLSearchParams(params).toString();
    return this.request(`/api/checks/logs?${qs}`);
  },

  // Settings
  getSettings() {
    return this.request('/api/settings');
  },

  updateSettings(data) {
    return this.request('/api/settings', {
      method: 'PUT',
      body: JSON.stringify(data),
    });
  },

  testTelegram() {
    return this.request('/api/settings/test-telegram', { method: 'POST' });
  },
};

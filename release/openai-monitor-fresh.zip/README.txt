OpenAI Monitor 全新交付版

这个压缩包已经去掉了本机数据库、历史日志、账号信息和 node_modules。
你的朋友解压后，第一次启动会自动创建一个全新的 data/monitor.db。

使用步骤
1. 先安装 Node.js 18 或更高版本。
2. 解压压缩包。
3. 双击 install-deps.bat。
4. 安装完成后，双击 start-monitor.bat。
5. 浏览器打开 http://localhost:3000

说明
- 首次运行是空项目，不会带任何账号、邀请记录、日志或 Telegram 配置。
- 如果 npm install 过程中需要下载浏览器，这是 Puppeteer 的正常行为。
- 如果启动窗口里出现 punycode 的废弃警告，一般不影响运行。

如果要停止服务，直接关闭启动窗口即可。

const express = require('express');
const http = require('http');
const db = require('../db');
const checker = require('../services/checker');
const quotaSync = require('../services/quota-sync');

const router = express.Router();

let isChecking = false;

// Active OAuth flows (state -> { codeVerifier, accountId, server })
const activeOAuthFlows = new Map();

// POST /api/checks/run — run check on all accounts
router.post('/run', async (req, res) => {
  if (isChecking) {
    return res.status(409).json({ error: 'A check is already in progress' });
  }

  isChecking = true;
  res.json({ message: 'Check started', status: 'running' });

  try {
    await checker.checkAllAccounts();
    await quotaSync.syncAllAccountUsage();
  } catch (err) {
    console.error('[Checks] Bulk check error:', err.message);
  } finally {
    isChecking = false;
  }
});

// POST /api/checks/:id — check single account
router.post('/:id(\\d+)', async (req, res) => {
  try {
    const result = await checker.checkSingleAccount(parseInt(req.params.id));
    if (result.status === checker.STATUS.ACTIVE) {
      await quotaSync.syncSingleAccountUsage(result.id).catch(err => {
        console.error('[Checks] Quota sync failed after single check:', err.message);
      });
    }
    res.json(result);
  } catch (err) {
    res.status(400).json({ error: err.message });
  }
});

// GET /api/checks/status — get checking status
router.get('/status', (req, res) => {
  res.json({ isChecking });
});

// GET /api/checks/logs — get check logs
router.get('/logs', (req, res) => {
  const { account_id, limit = 100, page = 1 } = req.query;
  let query = `
    SELECT cl.*, a.email, a.label
    FROM check_logs cl
    JOIN accounts a ON cl.account_id = a.id
  `;
  const params = [];

  if (account_id) {
    query += ' WHERE cl.account_id = ?';
    params.push(account_id);
  }

  query += ' ORDER BY cl.checked_at DESC';

  const offset = (parseInt(page) - 1) * parseInt(limit);
  query += ` LIMIT ? OFFSET ?`;
  params.push(parseInt(limit), offset);

  const logs = db.prepare(query).all(...params);
  res.json({ logs });
});

// ===== OAuth Routes =====

// POST /api/checks/oauth/start/:id — start OAuth flow for an account
router.post('/oauth/start/:id', (req, res) => {
  const accountId = parseInt(req.params.id);
  const account = db.prepare('SELECT * FROM accounts WHERE id = ?').get(accountId);
  if (!account) {
    return res.status(404).json({ error: 'Account not found' });
  }

  const { authUrl, codeVerifier, state } = checker.startOAuthFlow(account.email);

  // Start a temporary callback server on port 1455
  const callbackServer = http.createServer(async (req, cbRes) => {
    const url = new URL(req.url, 'http://localhost:1455');

    if (url.pathname === '/auth/callback') {
      const code = url.searchParams.get('code');
      const returnedState = url.searchParams.get('state');
      const error = url.searchParams.get('error');
      const errorDesc = url.searchParams.get('error_description') || error || '';

      if (error) {
        cbRes.writeHead(200, { 'Content-Type': 'text/html; charset=utf-8' });
        cbRes.end(`<html><body style="background:#0a0e17;color:#ef4444;font-family:Inter,sans-serif;display:flex;align-items:center;justify-content:center;height:100vh"><div style="text-align:center"><h2>❌ 授权失败</h2><p style="color:#8b95a5">${errorDesc}</p><p style="color:#4a5568;margin-top:12px">可以关闭此页面</p></div></body></html>`);
        callbackServer.close();
        activeOAuthFlows.delete(state);
        return;
      }

      if (returnedState !== state) {
        cbRes.writeHead(200, { 'Content-Type': 'text/html; charset=utf-8' });
        cbRes.end('<html><body style="background:#0a0e17;color:#ef4444;font-family:Inter,sans-serif;display:flex;align-items:center;justify-content:center;height:100vh"><h2>❌ 状态验证失败</h2></body></html>');
        callbackServer.close();
        activeOAuthFlows.delete(state);
        return;
      }

      try {
        const tokens = await checker.exchangeCodeForTokens(code, codeVerifier);

        // Save tokens to account
        db.prepare(`UPDATE accounts SET access_token = ?, refresh_token = ?, status = 'active', last_checked = datetime('now'), updated_at = datetime('now') WHERE id = ?`)
          .run(tokens.access_token, tokens.refresh_token || '', accountId);

        // Log the success
        db.prepare(`INSERT INTO check_logs (account_id, status, message) VALUES (?, 'active', '通过 OAuth 授权成功')`)
          .run(accountId);

        quotaSync.syncSingleAccountUsage(accountId).catch(syncErr => {
          console.error(`[OAuth] Quota sync failed for ${account.email}:`, syncErr.message);
        });

        cbRes.writeHead(200, { 'Content-Type': 'text/html; charset=utf-8' });
        cbRes.end('<html><body style="background:#0a0e17;color:#10b981;font-family:Inter,sans-serif;display:flex;align-items:center;justify-content:center;height:100vh"><div style="text-align:center"><h2>✅ 授权成功！</h2><p style="color:#8b95a5">令牌已保存，可以关闭此页面</p></div></body></html>');

        console.log(`[OAuth] Account ${account.email} authorized successfully`);
      } catch (err) {
        cbRes.writeHead(200, { 'Content-Type': 'text/html; charset=utf-8' });
        cbRes.end(`<html><body style="background:#0a0e17;color:#ef4444;font-family:Inter,sans-serif;display:flex;align-items:center;justify-content:center;height:100vh"><div style="text-align:center"><h2>❌ 令牌交换失败</h2><p style="color:#8b95a5">${err.message}</p></div></body></html>`);
        console.error(`[OAuth] Token exchange failed for ${account.email}:`, err.message);
      }

      callbackServer.close();
      activeOAuthFlows.delete(state);
    }
  });

  callbackServer.on('error', (err) => {
    if (err.code === 'EADDRINUSE') {
      console.error('[OAuth] Port 1455 is already in use');
      res.status(500).json({ error: '端口 1455 已被占用，请先关闭其他使用此端口的程序' });
    } else {
      console.error('[OAuth] Server error:', err.message);
    }
  });

  callbackServer.listen(1455, () => {
    console.log(`[OAuth] Callback server started on port 1455 for ${account.email}`);

    // Store flow info
    activeOAuthFlows.set(state, { codeVerifier, accountId, server: callbackServer });

    // Auto-cleanup after 3 minutes
    setTimeout(() => {
      if (activeOAuthFlows.has(state)) {
        activeOAuthFlows.delete(state);
        callbackServer.close();
        console.log('[OAuth] Flow timed out, callback server closed');
      }
    }, 180000);

    res.json({ authUrl, state });
  });
});

module.exports = router;

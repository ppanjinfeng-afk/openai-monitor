const express = require('express');
const db = require('../db');
const quotaSync = require('../services/quota-sync');

const router = express.Router();

function normalizeEmail(email) {
  return String(email || '').trim();
}

function findInviteRecord(accountId, email) {
  return db.prepare(`
    SELECT *
    FROM invites
    WHERE account_id = ?
      AND LOWER(target_email) = LOWER(?)
  `).get(accountId, normalizeEmail(email));
}

function getFallbackAccounts(excludedIds = []) {
  let query = `
    SELECT *
    FROM accounts
    WHERE status = 'active'
      AND access_token IS NOT NULL
      AND access_token != ''
      AND invited_count < invite_total
  `;
  const params = [];

  if (excludedIds.length > 0) {
    query += ` AND id NOT IN (${excludedIds.map(() => '?').join(',')})`;
    params.push(...excludedIds);
  }

  query += ' ORDER BY RANDOM()';
  return db.prepare(query).all(...params);
}

function persistInviteSuccess(account, targetEmail, result) {
  const existing = findInviteRecord(account.id, targetEmail);
  const requestedAccountId = result.requested_account_id || account.id;
  const fallbackFromAccountId = result.fallback_from_account_id || null;
  const remoteInviteId = result.remote_invite_id || '';
  const deliveryType = result.delivery_type || (result.wasResend ? 'resend' : 'send');

  if (!existing) {
    if (result.createdNewInvite) {
      db.prepare(`UPDATE accounts SET invited_count = COALESCE(invited_count, 0) + 1, updated_at = datetime('now') WHERE id = ?`).run(account.id);
    } else {
      db.prepare(`UPDATE accounts SET updated_at = datetime('now') WHERE id = ?`).run(account.id);
    }

    db.prepare(`
      INSERT INTO invites (
        account_id,
        requested_account_id,
        fallback_from_account_id,
        target_email,
        status,
        message,
        remote_invite_id,
        delivery_type
      ) VALUES (?, ?, ?, ?, 'sent', ?, ?, ?)
    `).run(account.id, requestedAccountId, fallbackFromAccountId, targetEmail, result.message, remoteInviteId, deliveryType);
  } else {
    db.prepare(`
      UPDATE invites
      SET updated_at = datetime('now'),
          status = 'sent',
          message = ?,
          requested_account_id = ?,
          fallback_from_account_id = ?,
          remote_invite_id = ?,
          delivery_type = ?
      WHERE id = ?
    `).run(result.message, requestedAccountId, fallbackFromAccountId, remoteInviteId, deliveryType, existing.id);
    db.prepare(`UPDATE accounts SET updated_at = datetime('now') WHERE id = ?`).run(account.id);
  }

  return existing;
}

function logInviteEvent(accountId, status, message) {
  db.prepare(`INSERT INTO check_logs (account_id, status, message) VALUES (?, ?, ?)`).run(accountId, status, message);
}

function formatInviteFailure(attempts) {
  return attempts.slice(0, 4).map(({ account, result }) => `${account.email}: ${result.message}`).join(' | ');
}

async function sendInviteWithFallback(primaryAccount, targetEmail, options = {}) {
  const inviter = require('../services/inviter');
  const attempts = [];
  const primaryResult = await inviter.sendTeamInvite(primaryAccount, targetEmail, {
    forceResend: Boolean(options.forceResend),
  });

  attempts.push({ account: primaryAccount, result: primaryResult });

  if (primaryResult.success || !options.allowFallback || primaryResult.code !== 'invite_not_materialized') {
    return { account: primaryAccount, result: primaryResult, attempts };
  }

  const fallbackAccounts = getFallbackAccounts([primaryAccount.id]).slice(0, 6);

  for (const fallbackAccount of fallbackAccounts) {
    const fallbackResult = await inviter.sendTeamInvite(fallbackAccount, targetEmail, {
      forceResend: Boolean(options.forceResend),
    });

    attempts.push({ account: fallbackAccount, result: fallbackResult });

    if (fallbackResult.success) {
      return { account: fallbackAccount, result: fallbackResult, attempts };
    }
  }

  return {
    account: primaryAccount,
    result: {
      ...primaryResult,
      message: formatInviteFailure(attempts),
    },
    attempts,
  };
}

// GET /api/accounts — list all accounts with optional status filter
router.get('/', (req, res) => {
  const { status, search, page = 1, limit = 50 } = req.query;
  let query = 'SELECT * FROM accounts';
  const conditions = [];
  const params = [];

  if (status && status !== 'all') {
    conditions.push('status = ?');
    params.push(status);
  }
  if (search) {
    conditions.push('(email LIKE ? OR label LIKE ?)');
    params.push(`%${search}%`, `%${search}%`);
  }

  if (conditions.length > 0) {
    query += ' WHERE ' + conditions.join(' AND ');
  }

  query += ' ORDER BY updated_at DESC';

  const offset = (parseInt(page) - 1) * parseInt(limit);
  const countQuery = query.replace('SELECT *', 'SELECT COUNT(*) as count');
  const total = db.prepare(countQuery).get(...params).count;

  query += ` LIMIT ? OFFSET ?`;
  params.push(parseInt(limit), offset);

  const accounts = db.prepare(query).all(...params);
  res.json({ accounts, total, page: parseInt(page), limit: parseInt(limit) });
});

// GET /api/accounts/stats — overall statistics
router.get('/stats', (req, res) => {
  const total = db.prepare('SELECT COUNT(*) as count FROM accounts').get().count;
  const active = db.prepare("SELECT COUNT(*) as count FROM accounts WHERE status = 'active'").get().count;
  const banned = db.prepare("SELECT COUNT(*) as count FROM accounts WHERE status = 'banned'").get().count;
  const invalid = db.prepare("SELECT COUNT(*) as count FROM accounts WHERE status = 'invalid_credentials'").get().count;
  const unknown = db.prepare("SELECT COUNT(*) as count FROM accounts WHERE status IN ('unknown', 'no_password', 'error', 'rate_limited')").get().count;
  const invites = db.prepare('SELECT COALESCE(SUM(invited_count),0) as used, COALESCE(SUM(invite_total),0) as total FROM accounts').get();
  const quotaSyncEligible = db.prepare(`
    SELECT COUNT(*) as count
    FROM accounts
    WHERE status = 'active'
      AND access_token IS NOT NULL
      AND access_token != ''
  `).get().count;
  const quotaStats = db.prepare(`
    SELECT
      COALESCE(SUM(CASE WHEN quota_sync_status = 'success' THEN 1 ELSE 0 END), 0) as synced,
      COALESCE(SUM(CASE WHEN quota_sync_status = 'error' THEN 1 ELSE 0 END), 0) as failed,
      COALESCE(SUM(CASE WHEN quota_sync_status = 'skipped' THEN 1 ELSE 0 END), 0) as skipped,
      COALESCE(SUM(CASE WHEN quota_sync_status = 'never' OR quota_sync_status IS NULL OR TRIM(quota_sync_status) = '' THEN 1 ELSE 0 END), 0) as never,
      COALESCE(SUM(CASE WHEN invited_count > invite_total THEN 1 ELSE 0 END), 0) as over_quota,
      COALESCE(SUM(CASE WHEN invited_count >= invite_total THEN 1 ELSE 0 END), 0) as full_quota,
      MAX(quota_last_synced_at) as last_synced_at
    FROM accounts
  `).get();

  res.json({
    total,
    active,
    banned,
    invalid,
    unknown,
    invitesUsed: invites.used,
    invitesTotal: invites.total,
    quotaSyncEligible,
    quotaSyncSuccess: quotaStats.synced,
    quotaSyncError: quotaStats.failed,
    quotaSyncSkipped: quotaStats.skipped,
    quotaSyncNever: quotaStats.never,
    quotaLastSyncedAt: quotaStats.last_synced_at,
    overQuota: quotaStats.over_quota,
    fullQuota: quotaStats.full_quota,
  });
});

router.post('/sync-quotas', async (req, res) => {
  try {
    const results = await quotaSync.syncAllAccountUsage();
    const summary = quotaSync.summarizeQuotaResults(results);

    res.json({
      message: `Quota sync completed: ${summary.synced} synced, ${summary.failed} failed`,
      ...summary,
      results,
    });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

// POST /api/accounts — add single account
router.post('/', (req, res) => {
  const { email, password, label, invite_link, invite_total, invited_count } = req.body;
  if (!email) {
    return res.status(400).json({ error: 'Email is required' });
  }

  const result = db.prepare(`
    INSERT INTO accounts (email, password, label, invite_link, invite_total, invited_count)
    VALUES (?, ?, ?, ?, ?, ?)
  `).run(email, password || '', label || '', invite_link || '', invite_total || 4, invited_count || 0);

  const account = db.prepare('SELECT * FROM accounts WHERE id = ?').get(result.lastInsertRowid);
  res.status(201).json(account);
});

// POST /api/accounts/batch — bulk import
router.post('/batch', (req, res) => {
  const { accounts } = req.body;
  if (!Array.isArray(accounts) || accounts.length === 0) {
    return res.status(400).json({ error: 'Accounts array is required' });
  }

  const insert = db.prepare(`
    INSERT INTO accounts (email, password, label, invite_link, invite_total, invited_count)
    VALUES (?, ?, ?, ?, ?, ?)
  `);

  let imported = 0;
  let errors = [];

  const importBatch = db.transaction(() => {
    for (const acc of accounts) {
      try {
        if (!acc.email) {
          errors.push({ email: acc.email || 'unknown', error: 'Email is required' });
          continue;
        }
        insert.run(
          acc.email,
          acc.password || '',
          acc.label || '',
          acc.invite_link || '',
          acc.invite_total || 4,
          acc.invited_count || 0
        );
        imported++;
      } catch (err) {
        errors.push({ email: acc.email, error: err.message });
      }
    }
  });

  importBatch();
  res.status(201).json({ imported, errors, total: accounts.length });
});

// PUT /api/accounts/:id — update account
router.put('/:id', (req, res) => {
  const { id } = req.params;
  const account = db.prepare('SELECT * FROM accounts WHERE id = ?').get(id);
  if (!account) {
    return res.status(404).json({ error: 'Account not found' });
  }

  const fields = ['email', 'password', 'label', 'invite_link', 'invite_total', 'invited_count', 'status'];
  const updates = [];
  const params = [];

  for (const field of fields) {
    if (req.body[field] !== undefined) {
      updates.push(`${field} = ?`);
      params.push(req.body[field]);
    }
  }

  if (updates.length === 0) {
    return res.status(400).json({ error: 'No fields to update' });
  }

  updates.push("updated_at = datetime('now')");
  params.push(id);

  db.prepare(`UPDATE accounts SET ${updates.join(', ')} WHERE id = ?`).run(...params);
  const updated = db.prepare('SELECT * FROM accounts WHERE id = ?').get(id);
  res.json(updated);
});

// DELETE /api/accounts/:id — delete account
router.delete('/:id', (req, res) => {
  const { id } = req.params;
  const account = db.prepare('SELECT * FROM accounts WHERE id = ?').get(id);
  if (!account) {
    return res.status(404).json({ error: 'Account not found' });
  }

  db.prepare('DELETE FROM check_logs WHERE account_id = ?').run(id);
  db.prepare('DELETE FROM accounts WHERE id = ?').run(id);
  res.json({ message: 'Account deleted' });
});

// DELETE /api/accounts — delete multiple accounts
router.delete('/', (req, res) => {
  const { ids } = req.body;
  if (!Array.isArray(ids) || ids.length === 0) {
    return res.status(400).json({ error: 'Account IDs array is required' });
  }

  const placeholders = ids.map(() => '?').join(',');
  db.prepare(`DELETE FROM check_logs WHERE account_id IN (${placeholders})`).run(...ids);
  db.prepare(`DELETE FROM accounts WHERE id IN (${placeholders})`).run(...ids);
  res.json({ deleted: ids.length });
});

// POST /api/accounts/:id/invite — send team invitation
router.post('/:id(\\d+)/sync-quota', async (req, res) => {
  const { id } = req.params;
  const account = db.prepare('SELECT * FROM accounts WHERE id = ?').get(id);

  if (!account) {
    return res.status(404).json({ error: 'Account not found' });
  }

  try {
    const result = await quotaSync.syncSingleAccountUsage(account);
    if (result.success || result.skipped) {
      return res.json(result);
    }

    return res.status(500).json({ error: result.message });
  } catch (err) {
    return res.status(500).json({ error: err.message });
  }
});

router.post('/:id(\\d+)/invite', async (req, res) => {
  try {
    const { email, force_resend: forceResend } = req.body;
    if (!email) {
      return res.status(400).json({ error: '请提供目标邮箱地址' });
    }

    const { id } = req.params;
    const account = db.prepare('SELECT * FROM accounts WHERE id = ?').get(id);
    
    if (!account) {
      return res.status(404).json({ error: 'Account not found' });
    }

    if (!account.access_token) {
      return res.status(400).json({ error: '该账号尚未进行 OAuth 授权，请先授权' });
    }

    const targetEmail = normalizeEmail(email);
    const delivery = await sendInviteWithFallback(account, targetEmail, {
      forceResend: Boolean(forceResend),
      allowFallback: Boolean(forceResend),
    });
    const usedAccount = delivery.account;
    const result = delivery.result;

    if (result.success) {
      const fallbackUsed = usedAccount.id !== account.id;
      const finalResult = {
        ...result,
        requested_account_id: account.id,
        fallback_from_account_id: fallbackUsed ? account.id : null,
        remote_invite_id: result.remoteInviteId || result.remote_invite_id || '',
        delivery_type: result.wasResend ? 'resend' : 'send',
        message: fallbackUsed
          ? `${result.message} (fallback account: ${usedAccount.email})`
          : result.message,
      };
      const existing = persistInviteSuccess(usedAccount, targetEmail, finalResult);

      if (fallbackUsed) {
        logInviteEvent(
          account.id,
          'error',
          `[resend-fallback] ${targetEmail} fallback to ${usedAccount.email}: ${delivery.attempts[0].result.message}`
        );
      }

      logInviteEvent(
        usedAccount.id,
        'active',
        `${existing || finalResult.wasResend ? '[resend] ' : '[invite] '}invite sent to ${targetEmail}${fallbackUsed ? ` via fallback from ${account.email}` : ''}`
      );
        
      res.json({
        ...finalResult,
        used_account: usedAccount.email,
        used_account_id: usedAccount.id,
        fallback_from_account: fallbackUsed ? account.email : null,
        is_resend: !!existing || !!finalResult.wasResend || Boolean(forceResend) || fallbackUsed,
      });
    } else {
      res.status(500).json({ error: result.message });
    }
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

// POST /api/accounts/auto-invite - send team invitation automatically using an available account
router.post('/auto-invite', async (req, res) => {
  try {
    const { email } = req.body;
    if (!email) {
      return res.status(400).json({ error: '请提供目标邮箱地址' });
    }

    // First check if this email was already invited
    let account = null;
    const targetEmail = normalizeEmail(email);
    const existingInvite = db.prepare(`
      SELECT *
      FROM invites
      WHERE LOWER(target_email) = LOWER(?)
      ORDER BY created_at DESC
      LIMIT 1
    `).get(targetEmail);
    
    if (existingInvite) {
      account = db.prepare(`SELECT * FROM accounts WHERE id = ? AND status = 'active'`).get(existingInvite.account_id);
    }
    
    if (!account) {
      account = db.prepare(`
        SELECT * FROM accounts 
        WHERE status = 'active' 
          AND access_token IS NOT NULL 
          AND access_token != ''
          AND invited_count < invite_total 
        ORDER BY RANDOM() 
        LIMIT 1
      `).get();
    }

    if (!account) {
      return res.status(404).json({ error: '没有可用的账号（均已满员或未授权/被封禁）' });
    }

    const delivery = await sendInviteWithFallback(account, targetEmail, {
      forceResend: Boolean(existingInvite),
      allowFallback: true,
    });
    const usedAccount = delivery.account;
    const result = delivery.result;

    if (result.success) {
      const fallbackUsed = usedAccount.id !== account.id;
      const finalResult = {
        ...result,
        requested_account_id: account.id,
        fallback_from_account_id: fallbackUsed ? account.id : null,
        remote_invite_id: result.remoteInviteId || result.remote_invite_id || '',
        delivery_type: result.wasResend ? 'resend' : 'send',
        message: fallbackUsed
          ? `${result.message} (fallback account: ${usedAccount.email})`
          : result.message,
      };
      const existing = persistInviteSuccess(usedAccount, targetEmail, finalResult);

      if (fallbackUsed) {
        logInviteEvent(
          account.id,
          'error',
          `[auto-invite-fallback] ${targetEmail} fallback to ${usedAccount.email}: ${delivery.attempts[0].result.message}`
        );
      }

      logInviteEvent(
        usedAccount.id,
        'active',
        `${existing || finalResult.wasResend || existingInvite ? '[auto-resend] ' : '[auto-invite] '}invite sent to ${targetEmail}${fallbackUsed ? ` via fallback from ${account.email}` : ''}`
      );
        
      res.json({
        ...finalResult,
        used_account: usedAccount.email,
        used_account_id: usedAccount.id,
        fallback_from_account: fallbackUsed ? account.email : null,
        is_resend: !!existing || !!finalResult.wasResend || !!existingInvite || fallbackUsed,
      });
    } else {
      res.status(500).json({ error: result.message, used_account: account.email });
    }
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

module.exports = router;

const express = require('express');
const db = require('../db');
const telegram = require('../services/telegram');
const scheduler = require('../services/scheduler');

const router = express.Router();

// GET /api/settings — get all settings
router.get('/', (req, res) => {
  const rows = db.prepare('SELECT * FROM settings').all();
  const settings = {};
  for (const row of rows) {
    settings[row.key] = row.value;
  }
  res.json(settings);
});

// PUT /api/settings — update settings
router.put('/', (req, res) => {
  const update = db.prepare('INSERT OR REPLACE INTO settings (key, value) VALUES (?, ?)');

  const allowedKeys = [
    'telegram_bot_token',
    'telegram_chat_id',
    'check_interval_minutes',
    'alerts_enabled',
    'daily_summary_enabled',
    'daily_summary_hour',
  ];

  const updateAll = db.transaction(() => {
    for (const [key, value] of Object.entries(req.body)) {
      if (allowedKeys.includes(key)) {
        update.run(key, String(value));
      }
    }
  });

  updateAll();

  // Restart scheduler if interval changed
  if (req.body.check_interval_minutes || req.body.daily_summary_enabled || req.body.daily_summary_hour) {
    scheduler.restartScheduler();
  }

  const rows = db.prepare('SELECT * FROM settings').all();
  const settings = {};
  for (const row of rows) {
    settings[row.key] = row.value;
  }
  res.json(settings);
});

// POST /api/settings/test-telegram — send a test message
router.post('/test-telegram', async (req, res) => {
  try {
    const success = await telegram.sendTestMessage();
    if (success) {
      res.json({ message: 'Test message sent successfully' });
    } else {
      res.status(400).json({ error: 'Failed to send test message. Check your Telegram configuration.' });
    }
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

module.exports = router;

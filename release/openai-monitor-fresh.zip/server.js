const express = require('express');
const cors = require('cors');
const path = require('path');

const app = express();
const PORT = process.env.PORT || 3000;

// Middleware
app.use(cors());
app.use(express.json({ limit: '10mb' }));
app.use(express.static(path.join(__dirname, 'public')));

// API Routes
app.use('/api/accounts', require('./routes/accounts'));
app.use('/api/checks', require('./routes/checks'));
app.use('/api/settings', require('./routes/settings'));
app.use('/api/invites', require('./routes/invites'));

// SPA fallback
app.get('*', (req, res) => {
  res.sendFile(path.join(__dirname, 'public', 'index.html'));
});

// Start server
app.listen(PORT, () => {
  console.log(`\n🚀 OpenAI Monitor running at http://localhost:${PORT}\n`);

  // Start the scheduler
  const scheduler = require('./services/scheduler');
  scheduler.startScheduler();
});

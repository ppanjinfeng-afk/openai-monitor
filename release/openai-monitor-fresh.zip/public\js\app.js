// Main Application Controller

const App = {
  currentPage: 'dashboard',
  accounts: [],
  stats: {},
  selectedIds: new Set(),
  currentEditId: null,
  currentAccountsPage: 1,
  currentInvitesPage: 1,
  searchTimeout: null,
  autoRefreshInterval: null,

  // ===== Init =====
  async init() {
    this.bindEvents();
    this.navigateTo('dashboard');
    this.startAutoRefresh();
  },

  setText(id, value) {
    const element = document.getElementById(id);
    if (element) {
      element.textContent = value;
    }
  },

  // ===== Navigation =====
  navigateTo(page) {
    this.currentPage = page;

    // Update nav items
    document.querySelectorAll('.nav-item').forEach(el => {
      el.classList.toggle('active', el.dataset.page === page);
    });

    // Show/hide pages
    document.querySelectorAll('.page').forEach(el => {
      el.classList.toggle('hidden', el.id !== `page-${page}`);
    });

    // Update title
    const titles = {
      dashboard: '仪表盘',
      accounts: '账号管理',
      logs: '检查日志',
      settings: '设置',
    };
    document.getElementById('page-title').textContent = titles[page] || page;

    // Load page data
    this.loadPageData(page);
  },

  async loadPageData(page) {
    switch (page) {
      case 'dashboard':
        await Promise.all([this.loadStats(), this.loadRecentLogs()]);
        break;
      case 'accounts':
        await Promise.all([this.loadAccounts(), this.loadStats()]);
        break;
      case 'logs':
        await this.loadLogs();
        break;
      case 'settings':
        await this.loadSettings();
        break;
      case 'invites':
        await this.loadInvites();
        break;
    }
  },

  // ===== Stats =====
  async loadStats() {
    try {
      this.stats = await API.getStats();
      this.setText('stat-total', this.stats.total);
      this.setText('stat-active', this.stats.active);
      this.setText('stat-banned', this.stats.banned);
      this.setText('stat-invites', `${this.stats.invitesUsed}/${this.stats.invitesTotal}`);

      const quotaSyncValue = `${this.stats.quotaSyncSuccess || 0}/${this.stats.quotaSyncEligible || 0}`;
      const quotaSyncMeta = this.stats.quotaLastSyncedAt
        ? `上次 ${Components.timeAgo(this.stats.quotaLastSyncedAt)}`
        : '从未同步';
      const overQuotaMeta = (this.stats.overQuota || 0) > 0
        ? `${this.stats.overQuota} 个超额`
        : `${this.stats.fullQuota || 0} 个已满`;

      this.setText('stat-quota-sync', quotaSyncValue);
      this.setText('stat-quota-sync-meta', quotaSyncMeta);
      this.setText('stat-over-quota', this.stats.overQuota || 0);
      this.setText('stat-over-quota-meta', overQuotaMeta);

      this.setText('quota-last-synced', quotaSyncMeta);
      this.setText(
        'quota-sync-summary',
        `${this.stats.quotaSyncSuccess || 0}/${this.stats.quotaSyncEligible || 0} 成功 · ${this.stats.quotaSyncError || 0} 失败`
      );
      this.setText(
        'quota-over-quota-summary',
        (this.stats.overQuota || 0) > 0
          ? `${this.stats.overQuota} 个账号超额`
          : `${this.stats.fullQuota || 0} 个账号已满`
      );
    } catch (err) {
      console.error('Failed to load stats:', err);
    }
  },

  // ===== Accounts =====
  async loadAccounts(page = this.currentAccountsPage) {
    try {
      this.currentAccountsPage = page;
      const searchInput = document.getElementById('search-input');
      const statusFilter = document.getElementById('status-filter');
      const params = { page };

      if (searchInput && searchInput.value) {
        params.search = searchInput.value;
      }
      if (statusFilter && statusFilter.value !== 'all') {
        params.status = statusFilter.value;
      }

      const data = await API.getAccounts(params);
      this.accounts = data.accounts;

      const tbody = document.getElementById('accounts-tbody');
      const empty = document.getElementById('accounts-empty');

      if (this.accounts.length === 0) {
        tbody.innerHTML = '';
        empty.classList.remove('hidden');
        document.querySelector('.accounts-table').classList.add('hidden');
      } else {
        empty.classList.add('hidden');
        document.querySelector('.accounts-table').classList.remove('hidden');
        tbody.innerHTML = this.accounts.map(acc => Components.accountRow(acc)).join('');
      }

      this.renderPagination(data);
      this.updateBulkActions();
    } catch (err) {
      console.error('Failed to load accounts:', err);
      this.toast('加载账号失败: ' + err.message, 'error');
    }
  },

  renderPagination(data) {
    const container = document.getElementById('pagination');
    if (data.total <= data.limit) {
      container.innerHTML = '';
      return;
    }

    const totalPages = Math.ceil(data.total / data.limit);
    let html = '';

    html += `<button ${data.page <= 1 ? 'disabled' : ''} onclick="App.goToPage(${data.page - 1})">‹</button>`;

    for (let i = 1; i <= totalPages; i++) {
      if (i === data.page) {
        html += `<button class="active">${i}</button>`;
      } else if (Math.abs(i - data.page) <= 2 || i === 1 || i === totalPages) {
        html += `<button onclick="App.goToPage(${i})">${i}</button>`;
      } else if (Math.abs(i - data.page) === 3) {
        html += `<button disabled>…</button>`;
      }
    }

    html += `<button ${data.page >= totalPages ? 'disabled' : ''} onclick="App.goToPage(${data.page + 1})">›</button>`;
    container.innerHTML = html;
  },

  goToPage(page) {
    this.loadAccounts(page);
  },

  // ===== Logs =====
  async loadRecentLogs() {
    try {
      const data = await API.getLogs({ limit: 20 });
      const container = document.getElementById('recent-logs');
      if (data.logs.length === 0) {
        container.innerHTML = `
          <div class="empty-state">
            <svg width="48" height="48" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5" opacity="0.3"><path d="M14 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V8z"/><polyline points="14 2 14 8 20 8"/></svg>
            <p>暂无检查记录</p>
          </div>`;
      } else {
        container.innerHTML = data.logs.map(log =>
          Components.logEntry(log)
        ).join('');
      }
    } catch (err) {
      console.error('Failed to load recent logs:', err);
    }
  },

  async loadLogs() {
    try {
      const data = await API.getLogs({ limit: 100 });
      const container = document.getElementById('logs-list');
      if (data.logs.length === 0) {
        container.innerHTML = '<div class="empty-state"><p>暂无日志</p></div>';
      } else {
        container.innerHTML = data.logs.map(log =>
          Components.logEntry(log)
        ).join('');
      }
    } catch (err) {
      console.error('Failed to load logs:', err);
      this.toast('加载日志失败', 'error');
    }
  },

  // ===== Invites =====
  async loadInvites(page = 1) {
    try {
      this.currentInvitesPage = page;
      const searchInput = document.getElementById('search-invites-input');
      const search = searchInput ? searchInput.value : '';
      
      const res = await API.getInvites({ page, limit: 50, search });
      
      const tbody = document.getElementById('invites-tbody');
      const emptyState = document.getElementById('invites-empty');
      const table = document.getElementById('invites-table');
      const pagination = document.getElementById('invites-pagination');
      
      if (res.invites.length === 0) {
        table.classList.add('hidden');
        emptyState.classList.remove('hidden');
        pagination.innerHTML = '';
      } else {
        table.classList.remove('hidden');
        emptyState.classList.add('hidden');
        tbody.innerHTML = res.invites.map(i => Components.inviteRow(i)).join('');
        this.renderInvitesPagination(res.total, res.page, res.limit);
      }
    } catch (err) {
      console.error('Failed to load invites:', err);
      this.toast('加载邀请记录失败', 'error');
    }
  },
  
  renderInvitesPagination(total, currentPage, limit) {
    const totalPages = Math.ceil(total / limit);
    const container = document.getElementById('invites-pagination');
    
    if (totalPages <= 1) {
      container.innerHTML = '';
      return;
    }

    let html = '';
    for (let i = 1; i <= totalPages; i++) {
      if (i === 1 || i === totalPages || (i >= currentPage - 2 && i <= currentPage + 2)) {
        html += `<button class="page-btn ${i === currentPage ? 'active' : ''}" onclick="App.loadInvites(${i})">${i}</button>`;
      } else if (i === currentPage - 3 || i === currentPage + 3) {
        html += `<span class="page-dots">...</span>`;
      }
    }
    container.innerHTML = html;
  },

  formatInviteResultMessage(result) {
    const details = [];
    const usedAccount = result.used_account || '';
    const fallbackFromAccount = result.fallback_from_account || '';
    const remoteInviteId = result.remote_invite_id || result.remoteInviteId || '';

    if (usedAccount) {
      details.push(`Used: ${usedAccount}`);
    }
    if (fallbackFromAccount) {
      details.push(`From: ${fallbackFromAccount}`);
    }
    if (remoteInviteId) {
      details.push(`RID: ${Components.shortId(remoteInviteId)}`);
    }

    return details.length > 0
      ? `${result.message} [${details.join(' | ')}]`
      : result.message;
  },

  async deleteInvite(id) {
    if (!confirm('确定要删除这条邀请记录吗？')) return;
    try {
      await API.deleteInvite(id);
      this.toast('记录已删除', 'success');
      this.loadInvites(this.currentInvitesPage);
      this.loadLogs();
      this.loadAccounts();
      this.loadStats();
    } catch (err) {
      this.toast(err.message, 'error');
    }
  },
  
  async resendInvite(accountId, email) {
    if (!confirm(`确定要使用原账号为 ${email} 重新发送邀请吗？\n（系统将自动识别为补发，不会重复扣除名额）`)) return;
    
    try {
      this.toast(`正在补发 ${email} 的邀请...`, 'info');
      const res = await API.inviteAccount(accountId, email, { force_resend: true });
      this.toast(`✅ ${this.formatInviteResultMessage(res)}`, 'success');
      this.loadInvites(this.currentInvitesPage);
    } catch (err) {
      this.toast(`❌ 补发失败: ${err.message}`, 'error');
    }
  },

  // ===== Settings =====
  async loadSettings() {
    try {
      const settings = await API.getSettings();
      document.getElementById('tg-bot-token').value = settings.telegram_bot_token || '';
      document.getElementById('tg-chat-id').value = settings.telegram_chat_id || '';
      document.getElementById('alerts-enabled').checked = settings.alerts_enabled === 'true';
      document.getElementById('check-interval').value = settings.check_interval_minutes || 30;
      document.getElementById('daily-summary-enabled').checked = settings.daily_summary_enabled === 'true';
      document.getElementById('daily-summary-hour').value = settings.daily_summary_hour || '9';
    } catch (err) {
      console.error('Failed to load settings:', err);
    }
  },

  async saveSettings(type) {
    try {
      let data;
      if (type === 'telegram') {
        data = {
          telegram_bot_token: document.getElementById('tg-bot-token').value,
          telegram_chat_id: document.getElementById('tg-chat-id').value,
          alerts_enabled: document.getElementById('alerts-enabled').checked ? 'true' : 'false',
        };
      } else {
        data = {
          check_interval_minutes: document.getElementById('check-interval').value,
          daily_summary_enabled: document.getElementById('daily-summary-enabled').checked ? 'true' : 'false',
          daily_summary_hour: document.getElementById('daily-summary-hour').value,
        };
      }

      await API.updateSettings(data);
      this.toast('设置已保存', 'success');
    } catch (err) {
      this.toast('保存失败: ' + err.message, 'error');
    }
  },

  async testTelegram() {
    const btn = document.getElementById('btn-test-telegram');
    btn.disabled = true;
    btn.textContent = '发送中...';

    try {
      // Save settings first
      await this.saveSettings('telegram');
      await API.testTelegram();
      this.toast('测试消息已发送，请检查 Telegram', 'success');
    } catch (err) {
      this.toast('发送失败: ' + err.message, 'error');
    } finally {
      btn.disabled = false;
      btn.textContent = '发送测试消息';
    }
  },

  // ===== Account Actions =====
  showAddModal() {
    this.currentEditId = null;
    this.showModal('添加账号', Components.addAccountModal());
    document.getElementById('account-form').addEventListener('submit', (e) => {
      e.preventDefault();
      this.handleSaveAccount();
    });
  },

  async editAccount(id) {
    const account = this.accounts.find(a => a.id === id);
    if (!account) return;

    this.currentEditId = id;
    this.showModal('编辑账号', Components.addAccountModal(account));
    document.getElementById('account-form').addEventListener('submit', (e) => {
      e.preventDefault();
      this.handleSaveAccount();
    });
  },

  async handleSaveAccount() {
    const data = {
      email: document.getElementById('acc-email').value,
      password: document.getElementById('acc-password').value,
      label: document.getElementById('acc-label').value,
      invite_link: document.getElementById('acc-invite-link').value,
      invite_total: parseInt(document.getElementById('acc-invite-total').value),
      invited_count: parseInt(document.getElementById('acc-invited-count').value),
    };

    try {
      if (this.currentEditId) {
        await API.updateAccount(this.currentEditId, data);
        this.toast('账号已更新', 'success');
      } else {
        await API.addAccount(data);
        this.toast('账号已添加', 'success');
      }
      this.closeModal();
      await this.loadAccounts();
      await this.loadStats();
    } catch (err) {
      this.toast('保存失败: ' + err.message, 'error');
    }
  },

  async deleteAccount(id) {
    if (!confirm('确定要删除此账号吗？')) return;

    try {
      await API.deleteAccount(id);
      this.toast('账号已删除', 'success');
      await this.loadAccounts();
      await this.loadStats();
    } catch (err) {
      this.toast('删除失败: ' + err.message, 'error');
    }
  },

  async checkSingle(id) {
    this.toast('正在检查...', 'info');
    try {
      const result = await API.checkAccount(id);
      this.toast(`检查完成: ${Components.statusLabels[result.status] || result.status}`, 'success');
      if (this.currentPage === 'accounts') {
        await this.loadAccounts();
      }
      await this.loadStats();
    } catch (err) {
      this.toast('检查失败: ' + err.message, 'error');
    }
  },

  async oauthAccount(id) {
    this.toast('正在启动 OAuth 授权...', 'info');
    try {
      const result = await API.startOAuth(id);
      // Open auth URL in new tab
      window.open(result.authUrl, '_blank');
      this.toast('已在新标签页打开授权页面，请在那里登录 OpenAI 账号', 'info');
      // Poll for completion
      setTimeout(() => this.loadAccounts(), 5000);
      setTimeout(() => this.loadAccounts(), 15000);
      setTimeout(() => this.loadAccounts(), 30000);
    } catch (err) {
      this.toast('OAuth 启动失败: ' + err.message, 'error');
    }
  },

  async checkAll() {
    const btn = document.getElementById('btn-check-all');
    btn.disabled = true;
    btn.classList.add('loading');

    try {
      await API.runCheckAll();
      this.toast('全量检查已启动，后台运行中', 'info');
    } catch (err) {
      this.toast('启动检查失败: ' + err.message, 'error');
    } finally {
      btn.disabled = false;
      btn.classList.remove('loading');
    }
  },

  async syncAllQuotas() {
    const btn = document.getElementById('btn-sync-quotas');
    if (btn) {
      btn.disabled = true;
      btn.classList.add('loading');
    }

    this.toast('正在同步全部名额...', 'info');

    try {
      const result = await API.syncAllQuotas();
      const summary = [`成功 ${result.synced}`];
      if (result.failed) summary.push(`失败 ${result.failed}`);
      if (result.skipped) summary.push(`跳过 ${result.skipped}`);
      if (result.overQuota) summary.push(`超额 ${result.overQuota}`);

      this.toast(`名额同步完成: ${summary.join(' / ')}`, result.failed ? 'warning' : 'success');
      await Promise.all([this.loadAccounts(this.currentAccountsPage), this.loadStats()]);
    } catch (err) {
      this.toast(`同步名额失败: ${err.message}`, 'error');
    } finally {
      if (btn) {
        btn.disabled = false;
        btn.classList.remove('loading');
      }
    }
  },

  async syncAccountQuota(id) {
    const account = this.accounts.find(item => item.id === id);
    const label = account ? account.email : `#${id}`;
    this.toast(`正在同步 ${label} 的名额...`, 'info');

    try {
      const result = await API.syncAccountQuota(id);
      if (result.skipped) {
        this.toast(`已跳过: ${result.message}`, 'warning');
      } else {
        const suffix = result.overQuota
          ? ` / 超额 ${Math.abs(result.remainingSeats)}`
          : ` / 剩余 ${result.remainingSeats}`;
        this.toast(
          `同步完成: ${result.email} => 已用 ${result.usedSeats} (成员 ${result.memberSeats} + 待接受 ${result.pendingInvites})${suffix}`,
          result.overQuota ? 'warning' : 'success'
        );
      }

      await Promise.all([this.loadAccounts(this.currentAccountsPage), this.loadStats()]);
    } catch (err) {
      this.toast(`同步名额失败: ${err.message}`, 'error');
    }
  },

  // ===== Import =====
  showImportModal() {
    this.showModal('批量导入', Components.importModal());
  },

  async handleImport() {
    const raw = document.getElementById('import-data').value.trim();
    if (!raw) {
      this.toast('请输入导入数据', 'warning');
      return;
    }

    let accounts = [];

    try {
      // Try JSON first
      accounts = JSON.parse(raw);
      if (!Array.isArray(accounts)) {
        accounts = [accounts];
      }
    } catch {
      // Try CSV format: email,api_key,label
      const lines = raw.split('\n').filter(l => l.trim());
      for (const line of lines) {
        const parts = line.split(',').map(s => s.trim());
        if (parts[0] && parts[0].includes('@')) {
          accounts.push({
            email: parts[0],
            password: parts[1] || '',
            label: parts[2] || '',
          });
        }
      }
    }

    if (accounts.length === 0) {
      this.toast('未识别到有效数据', 'error');
      return;
    }

    try {
      const result = await API.batchImport(accounts);
      this.toast(`成功导入 ${result.imported} 个账号`, 'success');
      if (result.errors.length > 0) {
        this.toast(`${result.errors.length} 个账号导入失败`, 'warning');
      }
      this.closeModal();
      await this.loadAccounts();
      await this.loadStats();
    } catch (err) {
      this.toast('导入失败: ' + err.message, 'error');
    }
  },

  // ===== Bulk Actions =====
  updateBulkActions() {
    const bar = document.getElementById('bulk-actions');
    const count = document.getElementById('selected-count');
    if (this.selectedIds.size > 0) {
      bar.classList.remove('hidden');
      count.textContent = `${this.selectedIds.size} 个已选`;
    } else {
      bar.classList.add('hidden');
    }
  },

  async bulkDelete() {
    if (!confirm(`确定要删除 ${this.selectedIds.size} 个账号吗？`)) return;

    try {
      await API.deleteAccounts([...this.selectedIds]);
      this.toast(`已删除 ${this.selectedIds.size} 个账号`, 'success');
      this.selectedIds.clear();
      await this.loadAccounts();
      await this.loadStats();
    } catch (err) {
      this.toast('批量删除失败: ' + err.message, 'error');
    }
  },

  // ===== Modal =====
  showModal(title, content) {
    document.getElementById('modal-title').textContent = title;
    document.getElementById('modal-body').innerHTML = content;
    document.getElementById('modal-overlay').classList.remove('hidden');
  },

  closeModal() {
    document.getElementById('modal-overlay').classList.add('hidden');
    this.currentEditId = null;
  },

  openInviteModal(id) {
    const modalContent = Components.inviteModal(id);
    document.getElementById('modal-title').textContent = '✉️ 发送 Team 邀请';
    document.getElementById('modal-body').innerHTML = modalContent;
    document.getElementById('modal-overlay').classList.remove('hidden');
    setTimeout(() => document.getElementById('invite-email').focus(), 100);
  },

  async handleSendInvite(id) {
    const emailInput = document.getElementById('invite-email');
    const email = emailInput.value.trim();
    if (!email) {
      this.toast('请输入受邀人的邮箱地址', 'error');
      return;
    }

    const btn = document.getElementById('btn-submit-invite');
    const originalText = btn.textContent;
    btn.textContent = '发送中... (请等待10-30秒)';
    btn.disabled = true;

    try {
      const res = await API.inviteAccount(id, email);
      this.closeModal();
      this.toast(`✅ 成功: ${this.formatInviteResultMessage(res)}`, 'success');
      this.loadLogs();
      this.loadAccounts(); // Refresh to update invited count maybe
      this.loadInvites(1);
    } catch (err) {
      this.toast(`❌ 发送失败: ${err.message}`, 'error');
    } finally {
      if (document.getElementById('btn-submit-invite')) {
        btn.textContent = originalText;
        btn.disabled = false;
      }
    }
  },

  openAutoInviteModal() {
    const modalContent = Components.autoInviteModal();
    document.getElementById('modal-title').textContent = '🤖 自动发送邀请';
    document.getElementById('modal-body').innerHTML = modalContent;
    document.getElementById('modal-overlay').classList.remove('hidden');
    setTimeout(() => document.getElementById('auto-invite-email').focus(), 100);
  },

  async handleAutoInvite() {
    const emailInput = document.getElementById('auto-invite-email');
    const email = emailInput.value.trim();
    if (!email) {
      this.toast('请输入受邀人的邮箱地址', 'error');
      return;
    }

    const btn = document.getElementById('btn-submit-auto-invite');
    const originalText = btn.textContent;
    btn.textContent = '自动分配并发送中... (请等待10-30秒)';
    btn.disabled = true;

    try {
      const res = await API.autoInvite(email);
      this.closeModal();
      this.toast(`✅ 成功: ${this.formatInviteResultMessage(res)}`, 'success');
      this.loadLogs();
      this.loadAccounts();
      this.loadStats();
      this.loadInvites(1);
    } catch (err) {
      this.toast(`❌ 发送失败: ${err.message}`, 'error');
    } finally {
      if (document.getElementById('btn-submit-auto-invite')) {
        btn.textContent = originalText;
        btn.disabled = false;
      }
    }
  },

  openBulkAutoInviteModal() {
    const modalContent = Components.bulkAutoInviteModal();
    document.getElementById('modal-title').textContent = '🚀 批量自动邀请';
    document.getElementById('modal-body').innerHTML = modalContent;
    document.getElementById('modal-overlay').classList.remove('hidden');
    setTimeout(() => document.getElementById('bulk-invite-emails').focus(), 100);
  },

  async handleBulkAutoInvite() {
    const emailInput = document.getElementById('bulk-invite-emails');
    const rawEmails = emailInput.value;
    
    // Parse emails splitting by any whitespace or punctuation
    const emails = rawEmails.split(/[\n,;|\s]+/)
      .map(e => e.trim())
      .filter(e => e && e.includes('@'));
      
    if (emails.length === 0) {
      this.toast('未在此文本中识别到有效的邮箱地址', 'error');
      return;
    }
    
    // Setup UI
    document.getElementById('bulk-invite-progress-container').classList.remove('hidden');
    const btnSubmit = document.getElementById('btn-submit-bulk-invite');
    const btnCancel = document.getElementById('btn-bulk-cancel');
    const statusText = document.getElementById('bulk-invite-status-text');
    const progressBar = document.getElementById('bulk-invite-progress-bar');
    const logsContainer = document.getElementById('bulk-invite-logs');
    
    btnSubmit.disabled = true;
    btnCancel.disabled = true;
    emailInput.disabled = true;
    
    let successCount = 0;
    let failCount = 0;
    
    const appendLog = (msg, color = 'var(--text-primary)') => {
      const el = document.createElement('div');
      el.style.color = color;
      el.style.marginBottom = '4px';
      el.textContent = msg;
      logsContainer.appendChild(el);
      logsContainer.scrollTop = logsContainer.scrollHeight;
    };
    
    appendLog(`📝 共识别到 ${emails.length} 个邮箱，开始处理...`, 'var(--blue)');
    
    for (let i = 0; i < emails.length; i++) {
      const email = emails[i];
      statusText.textContent = `${i + 1} / ${emails.length}`;
      progressBar.style.width = `${((i) / emails.length) * 100}%`;
      
      appendLog(`[${i+1}/${emails.length}] 正在分配并发送邀请 -> ${email} ...`, 'var(--text-secondary)');
      
      try {
        const res = await API.autoInvite(email);
        successCount++;
        appendLog(`   ✅ 成功: ${this.formatInviteResultMessage(res)}`, 'var(--green)');
      } catch (err) {
        failCount++;
        appendLog(`   ❌ 失败: ${err.message}`, 'var(--red)');
        
        if (err.message.includes('没有可用') || err.message.includes('均已满员')) {
          appendLog(`⚠️ 检测到无可用账号剩余，停止后续排队任务！`, 'var(--yellow)');
          break; // Stop completely to save time as no accounts are left
        }
      }
      
      // Delay to avoid strict rate limiting
      if (i < emails.length - 1) {
        await new Promise(r => setTimeout(r, 2000));
      }
    }
    
    progressBar.style.width = '100%';
    statusText.textContent = `完成: 成功 ${successCount}, 失败 ${failCount}`;
    appendLog(`=============`, 'var(--text-secondary)');
    appendLog(`🎉 批量任务结束。成功: ${successCount}, 失败: ${failCount}`, 'var(--blue)');
    
    // UI clean up
    btnCancel.textContent = '完成 / 关闭';
    btnCancel.disabled = false;
    
    this.loadLogs();
    this.loadAccounts();
    this.loadStats();
  },

  // ===== Toast =====
  toast(message, type = 'info') {
    const container = document.getElementById('toast-container');
    const icons = {
      success: '✅',
      error: '❌',
      warning: '⚠️',
      info: 'ℹ️',
    };

    const toast = document.createElement('div');
    toast.className = `toast ${type}`;
    toast.innerHTML = `<span>${icons[type] || ''}</span><span>${message}</span>`;
    container.appendChild(toast);

    setTimeout(() => {
      toast.classList.add('toast-exit');
      setTimeout(() => toast.remove(), 300);
    }, 3500);
  },

  // ===== Auto Refresh =====
  startAutoRefresh() {
    this.autoRefreshInterval = setInterval(() => {
      if (this.currentPage === 'dashboard') {
        this.loadStats();
        this.loadRecentLogs();
      } else if (this.currentPage === 'accounts') {
        this.loadAccounts();
        this.loadStats();
      }
    }, 30000); // 30 seconds
  },

  // ===== Events =====
  bindEvents() {
    // Navigation
    document.querySelectorAll('.nav-item').forEach(el => {
      el.addEventListener('click', (e) => {
        e.preventDefault();
        this.navigateTo(el.dataset.page);
      });
    });

    // Mobile menu
    document.getElementById('menu-toggle').addEventListener('click', () => {
      document.getElementById('sidebar').classList.toggle('open');
    });

    // Header actions
    document.getElementById('btn-refresh').addEventListener('click', () => {
      this.loadPageData(this.currentPage);
      this.toast('数据已刷新', 'info');
    });

    document.getElementById('btn-check-all').addEventListener('click', () => {
      this.checkAll();
    });

    const btnSyncQuotas = document.getElementById('btn-sync-quotas');
    if (btnSyncQuotas) {
      btnSyncQuotas.addEventListener('click', () => {
        this.syncAllQuotas();
      });
    }

    // Account actions
    document.getElementById('btn-add-account').addEventListener('click', () => {
      this.showAddModal();
    });

    const btnBulkAutoInvite = document.getElementById('btn-bulk-auto-invite');
    if (btnBulkAutoInvite) {
      btnBulkAutoInvite.addEventListener('click', () => {
        this.openBulkAutoInviteModal();
      });
    }

    const btnAutoInvite = document.getElementById('btn-auto-invite');
    if (btnAutoInvite) {
      btnAutoInvite.addEventListener('click', () => {
        this.openAutoInviteModal();
      });
    }

    document.getElementById('btn-import').addEventListener('click', () => {
      this.showImportModal();
    });

    // Search
    document.getElementById('search-input').addEventListener('input', () => {
      clearTimeout(this.searchTimeout);
      this.searchTimeout = setTimeout(() => this.loadAccounts(1), 300);
    });

    // Status filter
    document.getElementById('status-filter').addEventListener('change', () => {
      this.loadAccounts(1);
    });

    // Select all checkbox
    document.getElementById('select-all-checkbox').addEventListener('change', (e) => {
      const checkboxes = document.querySelectorAll('.account-checkbox');
      this.selectedIds.clear();
      checkboxes.forEach(cb => {
        cb.checked = e.target.checked;
        if (e.target.checked) {
          this.selectedIds.add(parseInt(cb.dataset.id));
        }
      });
      this.updateBulkActions();
    });

    // Delegate account checkbox clicks
    document.getElementById('accounts-tbody').addEventListener('change', (e) => {
      if (e.target.classList.contains('account-checkbox')) {
        const id = parseInt(e.target.dataset.id);
        if (e.target.checked) {
          this.selectedIds.add(id);
        } else {
          this.selectedIds.delete(id);
        }
        this.updateBulkActions();
      }
    });

    // Bulk delete
    document.getElementById('btn-bulk-delete').addEventListener('click', () => {
      this.bulkDelete();
    });

    // Modal close
    document.getElementById('modal-close').addEventListener('click', () => {
      this.closeModal();
    });
    document.getElementById('modal-overlay').addEventListener('click', (e) => {
      if (e.target === e.currentTarget) this.closeModal();
    });

    // Settings
    document.getElementById('btn-save-telegram').addEventListener('click', () => {
      this.saveSettings('telegram');
    });
    document.getElementById('btn-test-telegram').addEventListener('click', () => {
      this.testTelegram();
    });
    document.getElementById('btn-save-schedule').addEventListener('click', () => {
      this.saveSettings('schedule');
    });

    // Invites
    const searchInvitesInput = document.getElementById('search-invites-input');
    if (searchInvitesInput) {
      let timeout = null;
      searchInvitesInput.addEventListener('input', () => {
        clearTimeout(timeout);
        timeout = setTimeout(() => this.loadInvites(1), 500);
      });
    }

    const btnRefreshInvites = document.getElementById('btn-refresh-invites');
    if (btnRefreshInvites) {
      btnRefreshInvites.addEventListener('click', () => {
        this.loadInvites(this.currentInvitesPage);
      });
    }

    // Keyboard shortcuts
    document.addEventListener('keydown', (e) => {
      if (e.key === 'Escape') this.closeModal();
    });
  },
};

// Start the app
document.addEventListener('DOMContentLoaded', () => App.init());
